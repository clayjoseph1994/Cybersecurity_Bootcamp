## Protocols and Port Numbers


**Instructions**

* For each protocol, identify its correct port number. 

| Protocol       | Port     |
|----------------|----------|
| FTP-Data       |          |
| SSH            |          |
| Telnet         |          |
| SMTP           |          |
| DNS            |          |
| HTTP           |          |
| SFTP           |          |
| SQL Server     |          |
| SNMP           |          |
| BGP            |          |
| LDAP           |          |
| DHCP           |          |
| Kerberos       |          |
| IRC            |          |
| HTTPS          |          |
| IMAP           |          |
| POP Version 3  |          |

* For each protocol, give a brief description.

| Protocol       | Description      |
|----------------|------------------|
| FTP-Data       |                  |
| SSH            |                  |
| Telnet         |                  |
| SMTP           |                  |
| DNS            |                  |
| HTTP           |                  |
| SFTP           |                  |
| SQL Server     |                  |
| SNMP           |                  |
| BGP            |                  |
| LDAP           |                  |
| DHCP           |                  |
| Kerberos       |                  |
| IRC            |                  |
| HTTPS          |                  |
| IMAP           |                  |
| POP Version 3  |                  |
