## GP: Installing Packages

- In this next activity, students will combine their knowledge of nano and package management to install `cowsay` and `fortune`.

* Using  `sudo`, students must be able to..

* Use apt to install fortune and cowsay
* Add a line to ~/.bashrc that prints a cowsay message with `fortune | cowsay -f tux`
* Start a new terminal to see the effect of adding this script to ~/.bashrc

- Instructions:
  - In this activity you will be installing the applications `Fortune` and `Cowsay`.
    - Fortune is a application that gives you a random quote every time you open the terminal up.
    - Cowsay is an application that creates an ASCII character appear to tell you your quote.
  - You will need to use the command that you have learned from the installing packages section in order to complete this in class assignment.
    - HINT: `apt install <package-name>`

  > **SOLUTION:** `sudo apt install fortune` and `sudo apt install cowsay`
  > - **Alternate Solution**: `sudo apt install fortune cowsay`

- To test this command, run ` fortune | cowsay -f tux`
  - Your output should be similar to:

  ```bash
  / It is by the fortune of God that, in   \
  | this country, we have three benefits:  |
  | freedom of speech, freedom of thought, |
  | and the wisdom never to use either.    |
  |                                        |
  \ -- Mark Twain                          /
   ----------------------------------------
   \
    \
        .--.
       |o_o |
       |:_/ |
      //   \ \
     (|     | )
    /'\_   _/`\
    \___)=(___/
  ```

- Once you have `Fortune` and `Cowsay` and you have tested the command to make sure it works, you will need to make changes to the `~/.bashrc` file so the command runs each time you open your terminal.

- The`~/.bashrc` file is a configuration file that runs commands every time you open a terminal.
    
  - Add the following line to the very bottom of the `~/.bashrc` file:
  - `fortune | cowsay -f tux`
  - **HINT:** Use `nano` to edit the `~/.bashrc` file.

  > **SOLUTION:** Run `nano ~/.bashrc` and append the line `fortune | cowsay -f tux` to the bottom of the file.

  Your file should look something like this (at the very bottom):

  ```bash
  # enable programmable completion features (you don't need to enable
  # this, if it's already enabled in /etc/bash.bashrc and /etc/profile
  # sources /etc/bash.bashrc).
  if ! shopt -oq posix; then
    if [ -f /usr/share/bash-completion/bash_completion ]; then
      . /usr/share/bash-completion/bash_completion
    elif [ -f /etc/bash_completion ]; then
      . /etc/bash_completion
    fi
  fi

  fortune | cowsay -f tux
  ```
  - Save the file.


> **Alternate Solution**: `echo "fortune | cowsay -f tux" >> ~/.bashrc`
>- You can run this command instead of opening the `~/.bashrc` file using nano
 

- Close your terminal and open a new Terminal.
 
- Verify that you can see Tux giving you a random quote.

```bash
/ And do you think (fop that I am) that I \
\ could be the Scarlet Pumpernickel?      /
 -----------------------------------------
   \
    \
        .--.
       |o_o |
       |:_/ |
      //   \ \
     (|     | )
    /'\_   _/`\
    \___)=(___/
```