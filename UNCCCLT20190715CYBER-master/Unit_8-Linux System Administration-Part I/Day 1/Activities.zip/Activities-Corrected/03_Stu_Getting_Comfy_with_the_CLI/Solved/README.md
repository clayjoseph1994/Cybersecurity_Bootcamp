# Getting Comfy with the CLI

## Instructions

### Review

- Inside your VM, Move into your home directory, and then into your Documents folder.

- Create the following directories:
  - `Class_Notes`
  - `Class_Resources`

**Solution**: `mkdir Class_Notes Class_Resources`

- Move into `Class_Notes`, and create a file called `Linux_Notes`.

**Solution**: `cd Class_Notes` and `touch Linux_Notes`

- Create a folder called `12_Intro_to_Windows_and_Linux` in `Class_Notes`, and move `Linux_Notes` into this folder.

**Solution**: 
    
    - `mkdir 12_Intro_to_Windows_and_Linux`
    - `mv Linux_Notes 12_Intro_to_Windows_and_Linux`


- Use `man rm`, and search for the `-i` flag. What does it do?

**Solution**: `rm -i` enables the 'interactive' option that will prompt before removing an item.

- Use `rm -i` to try to remove `Linux_Notes`, but choose _not_ to remove the file.

### Using Manpages

- Change back to your home directory, and list all the files.

**Solution**: `cd` and `ls`

- Run `ls --help | less`, and search for "all". Note the two flags you discover.

**Solution**: You can search by pressing `/` and typing your search term.

- List all files in your home directory. Write down the names of all the new files you see.

**Solution**: `ls -a`

- Look at the first few file names.
- Which can you read? What do you think each one does?

**Solution**: The hidden files start with a `.`

- Use the help page to find out how to use `ls` in "long listing format".
  - **Hint**: Run `ls --help | less`, then search for "long listing".

**Solution**: You can search by pressing `/` and typing your search term.

- Use the above two options together to list every file in your home directory with the `long` listing format.

**Solution**: `ls -la` 

- Use the manpages to find out how to use `ls` to sort alphabetically.

**Solution**: `ls` sorts alphabetically automatically.

- List every file in your home directory in alphabetical order, in long listing format.

**Solution**: `ls -l`

## Bonus
- Suppose you want to use `cut` to chop up the following line in a file: `Jane;Doe;jane@gmail.com;24`. 

- The fields contain her first and last name; email; and age, respectively.

- Which delimiter should you use?

**Solution**: `-d ';'` 

  - Which field do you specify if you want to get her first name?

**Solution**: `-f1`

You can test this by running:
```bash
$ echo 'Jane;Doe;jane@gmail.com;24' | cut -d ';' -f1
Jane
```

  - Which field do you specify if you want to get her age?

**Solution**: `-f4`
```bash
$ echo 'Jane;Doe;jane@gmail.com;24' | cut -d ';' -f4
24
```
  - Which field do you specify if you want to get her last name?

**Solution**: `-f2`
```bash
$ echo 'Jane;Doe;jane@gmail.com;24' | cut -d ';' -f2
Doe
```
  - Which field do you specify if you want to get her email?

**Solution**: `-f3`
```bash
$ echo 'Jane;Doe;jane@gmail.com;24' | cut -d ';' -f3
jane@gmail.com
```
  - Which fields do you specify if you want to get her first _and_ last name?

**Solution**: `-f1-2`
```bash
$ echo 'Jane;Doe;jane@gmail.com;24' | cut -d ';' -f1-2
Jane;Doe
```