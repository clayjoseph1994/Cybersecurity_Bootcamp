## Nano nano
In this exercise, you will need to use nano to complete the challenges below.

## nano

- Create a directory called `~/Documents/Office`.

  > **Solution**: `mkdir ~/Documents/Office`

- Use `nano` to create a file called `supplies.txt` in the directory and begin editing the file. 

  > **Solution**: `nano supplies.txt`

### Get Help

- While nano is open for your file, review the function options at the bottom of the `nano` environment screen.

- Choose the option to `Get Help`.
  > **Solution**: `Ctrl g`

- Read the first 2 paragraphs of the Get Help section. 

  > **Solution**: Notice that you can learn a lot about using `nano` from this help area.

- Exit the Get Help section and return to your document.

  > **Solution**: `Ctrl x`

### Edit Text

- For typing text, the `nano` editor works much like any other text editor. 

- List the following office supplies in your document.

	- New computer
	- Red Stapler
	- Coffee cup
	- Motivational kitten picture.
	- Pens

  > **Solution**: You can type, add bullet points using the `-` and move the cursor around with the arrow keys. 

### Save

- Choose the option to `Write Out` at the bottom of the file.
  > **Solution**: `Ctrl o`
	- `Write out` is a _save_ function and allows you to save your progress.
	- This will confirm the name of the file and allow you to change it if needed. 
	- Press `Enter` to confirm the name and write the file.

### Search

- Choose the option at the bottom of the screen for `Where Is`.
  > **Solution**: `Ctrl w`
	- 'Where is' allows you to search for a word. 
	- Search for the word `cup` and hit enter.
  > **Solution**: `Ctrl w` -> Type `cup` -> press enter and the cursor moves to the word cup.
	- Search for the word `poster`
  > **Solution**: `Ctrl w` -> Type `poster` -> press enter and the cursor moves to the word poster.

### Cut and Paste

- Review the options at the bottom of the screen for `Cut Text` and `Uncut Text`. Think of these options like `copy` and `paste`.
	- Position the cursor on the line `Coffee cup` and use the `Cut Text` function.
  > **Solution**: `Ctrl k` will cut the entire line.
	- Move to the bottom of your list and use the `Uncut Text` Function.
  > **Solution**: `Ctrl u` will paste the entire line.
	- Using these cut and uncut functions, modify your list so it reads:

		- Motivational kitten poster.
		- New Computer
		- Pens
		- Coffee Cup
		- Red Stapler

  > **Solution**: Cut and paste `Red Stapler` to the bottom of the list. Cut and paste `Motivational kitten poster` to the top of the list.

### Save and Quit

- Notice the function at the bottom left corner of the screen titled `Exit`

	- Choose this function and you will be asked if you want to save your changes before exiting. 
  > **Solution**: `Ctrl x`
	- Choose yes and you will be asked if you want to keep the same file name.
  > **Solution**: Press `y` to choose yes.
	- Press enter to save the file under the current name.
  > **Solution**: Press `Enter` to quit.
  > - Notice that saving and quitting the file requires 3 actions: 
	> - Press `Ctrl x`
	> - Press `y` to confirm you're saving changes.
	> - Press `enter` to confirm the file name.

## Bonus

- Create a directory called "Books" and place a file (that you create) called "school_books.txt" into the directory. 

- Using nano, list the following books in the "school_books.txt" file
	- A tale of two cities
	- Frankenstein 
	- The Great Gatsby
	- Hogwarts: A History
	- How to Kill a mockingbird

- Save and quit your file.


**Solution**:
  ```bash
	$ mkdir Books
	$ cd Books
	$ nano school_books.txt
  ```

Inside nano:

```bash
  GNU nano 2.7.4                             File: school_books.txt
  ------------------------------------------------------------------
	
	- A tale of two cities
	- Frankenstein 
	- The Great Gatsby
	- Hogwarts: A History
	- How to Kill a mockingbird







^G Get Help     ^O Write Out    ^W Where Is     ^K Cut Text    ...
^X Exit         ^R Read File    ^\ Replace      ^U Uncut Text ... 
```

Save and Quit with the commands:

	- `Ctrl x`
	- `y`
	- `Enter