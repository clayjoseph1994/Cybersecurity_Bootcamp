# Linux Landmarks

In the previous exercise, you found files in a variety of different directories, such as `/home` and `/var/log`.

These are important directories on Linux systems. In this activity, you'll have an opportunity to explore these and other important locations on the file system.

## Instructions

- Move to the `/` directory, and run `ls`.
  - What does this directory contain?
    - This is the **root** directory. It contains all other files on the system.

- Move to `/etc`, and list the files it contains.

Your output will have many files and look similar to:

```bash
adduser.conf            hosts.allow      python
aliases                 hosts.deny       python2.7
alternatives            ifplugd          python3
apache2                 ImageMagick-6    python3.5
apm                     init             qubes
apparmor                init.d           qubes-rpc
apparmor.d              initramfs-tools  qubes-suspend-module-blacklist
apt                     inputrc          rc0.d
avahi                   insserv          rc1.d
bash.bashrc             insserv.conf     rc2.d
bash_completion         insserv.conf.d   rc3.d
bash_completion.d       iproute2         rc4.d
bindresvport.blacklist  issue            rc5.d
```

Use `cat` to read `/etc/passwd`.
  
  > **Solution**: `cat /etc/passwd`.

Use `sudo cat` to read `/etc/shadow`.

  > **Solution**: `sudo cat /etc/shadow`

Read `man 5 shadow`. What does the `shadow` file contain?
    
   > **Solution**: `/etc/shadow` contains the hashed passwords of every user on the system.

Read `/etc/hosts`. What does this file contain? Refer to the reading if you're stuck.
     
> **Solution**: `/etc/hosts` is a local DNS database. It contains the IP <-> Hostname mappings that the server understands on its own. To resolve any IP addresses _not_ contained in this file, the server will have to query a different DNS database.

Move to `/bin`, and list the files it contains.

  > **Solution**: `cd /bin` and `ls`

There aer many files here. Your output will look similar to:

```bash
bash           grep            ntfs-3g        sync
bunzip2        gunzip          ntfs-3g.probe  systemctl
busybox        gzexe           ntfscat        systemd
bzcat          gzip            ntfscluster    systemd-ask-password
bzcmp          hostname        ntfscmp        systemd-escape
bzdiff         ip              ntfsfallocate  systemd-hwdb
bzegrep        journalctl      ntfsfix        systemd-inhibit
bzexe          kbd_mode        ntfsinfo       systemd-machine-id-setup
bzfgrep        kill            ntfsls         systemd-notify
bzgrep         kmod            ntfsmove       systemd-sysusers
bzip2          ksh             ntfsrecover    systemd-tmpfiles
bzip2recover   ksh93           ntfssecaudit   systemd-tty-ask-password-agent
bzless         less            ntfstruncate   tailf
bzmore         lessecho        ntfsusermap    tar
```

Move to `/usr/bin`, and list the files it contains.

  > **Solution**: `cd /usr/bin` and `ls`

There are many files here. Your output should look similar to:

```bash
2to3                                pbmtoepson
2to3-2.7                            pbmtog3
2to3-3.5                            pbmtogem
411toppm                            pbmtogo
aa-enabled                          pbmtoicon
aa-exec                             pbmtolj
addpart                             pbmtomacp
addr2line                           pbmtomda
animate                             pbmtomgr
animate-im6                         pbmtonokia
animate-im6.q16                     pbmtopgm
ant                                 pbmtopi3
anytopnm                            pbmtoplot
```

Look closely at the contents of these directories, specifically at the files beginning with the letters `l`, `c`, and `t`. Do you notice anything familiar?

  >**Solution**: You'll notice `cd`, `ls`, and `touch`, amongst other familiar commands.

Move to `/var`, and list the directories it contains.

  > **Solution**: `cd /var ` and `ls`

Your output should look similar to:

```bash
backups  cache  lib  local  lock  log  mail  opt  run  spool  tmp
```

Some of these will be unfamiliar, but what do you think the following contain?
  
  > **Solution**:
  > - `/var/backups`: Contains system backups.
  > - `/var/tmp`: Contains _temporary_ files. This is like a "scratchpad" for running processes.
  >  - `/var/log`: Contains log files. This is where running programs save important information about errors, warnings, etc.

- Return to `/home`. What does this directory contain?

  > **Solution**: `cd /home` and `ls`
  > - `/home` contains each user's personal, private directories.

- Move to `/tmp`. What kind of data do you think this directory contains?
  
  > **Solution**: `cd /tmp`
  > - Similar to  `/var/tmp`, the `/tmp` directory contains temporary data.

- What's the difference between `/tmp` and `/var/tmp`?
   
  > **Solution**: `/tmp` is also a scratchpad for running programs. Unlike `/var/tmp`, the contents of the top-level `/tmp` directory are deleted every time the system restarts.

## Questions

Read the following document before working through the questions below: <http://linuxcommand.org/lc3_lts0040.php>

- What kinds of files does `/` contain?
  
  >**Solution**: `/` contains every other file on the computer.

- What kinds of files does `/etc` contain?
  
  >**Solution**: `/etc/` contains important configuration files.

- What kinds of files does `/var` contain?
  
  >**Solution**: `/var` contains "variable" files—i.e., files that change over time, such as process logs; backups; et.

- What kinds of files do `/bin`, `/usr/bin`, and `/usr/sbin` contain?
  
  >**Solution**: `/bin` and `/usr/bin` contain executables, i.e., programs that the user and/or system can run, such as `ls`.

- What's the difference between these different "bin" directories?
  
  >**Solution**: 
  > - `/bin` contains programs that the system needs to survive, like `bash`.
  > - `/usr/bin` contains programs that are mostly user-facing, such as `cat` and `ls`.
  > - `/usr/sbin` contains programs that are used by users, but for system administration, such as `adduser`.

- What kinds of files does `/home` contain?
  
  > **Solution**: `/home` contains each users' personal data.

- Suppose you're looking for a program called `chpasswd`. Which directories would you look in first?
  
  > **Solution**:
  > - The first places to look would be `/bin`, `/usr/bin`, and `/usr/sbin`.
  > - In this case, `chpasswd` would be in `/usr/sbin`, because it's used by _users_ who are _system_ administrators.

- You've been told to find a configuration file called `fstab`. Which directory should you look in?
  
  > **Solution**: Configuration files live in `/etc`, so we'd look at `/etc/fstab`.

- An investigator tipped you that `hera` is also a malicious user. What's the first directory you'd look in to examine the files she's saved on the system?
  
  > **Solution**: The first place to look would be `/home/hera`.

- Which file would you read to get a list of all the users on the system?
  
  > **Solution**: Usernames for everyone on the system are stored in `/etc/passwd`.

- Which file would you read to get all users' hashed passwords?
  
  > **Solution**: Hashed passwords are stored in `/etc/shadow`.

- Suppose you've compromised a target machine, and you want to write a custom exploit while you're there. Which directory would you save it in to best cover your tracks?
  
  > **Solution**: A common place to save files like this is `/tmp`, because it's cleared by the system on reboot.
