# tcpdump and Access Control
In this exercise, you'll learn how to create packet captures with tcpdump.

We will cover:
  - Packet Captures with tcpdump
  - Implement `deny` rules with `ufw`

## Instructions

### Packet Captures with tcpdump

Refer to the tcpdump Primer: <https://danielmiessler.com/study/tcpdump/>

- On the Workstation, move to `/tmp`.

- Start a packet capture, and save it to the file `capture.pcap`.

- Let it run for a few moments and then stop the capture.

- Open the capture with Wireshark.

Now that you understand how to use tcpdump, use it to create captures instead of wireshark.

### Web Traffic
  - Use tcpdump to capture only HTTP traffic.

  - Open Firefox, and begin browsing the web. Navigate wherever you'd like, but make sure you browse to one of the below at least once:
      - `http://collegehumor.com`
      - `http://example.com`
  
  - Return to your tcpdump packet capture and stop the capture.
  
  - Enable UFW, turn on logging, and run `ufw status` to verify that these commands worked.
  
  - Configure UFW to deny all incoming and outgoing HTTP traffic.
    - **Note**: Use the port number, _not_ the protocol name.
  
  - Use `status verbose` to verify your firewall rules.
  
  - Begin capturing HTTP traffic with tcpdump again.
  
  - Launch Firefox, and begin browsing the web. Again, try browsing to one of the two sites below. 
      - `http://collegehumor.com`
      - `http://example.com`
  
  - Stop the tcpdump capture.
  
  - Check your Wireshark capture, and make sure it syncs up with your browsing experience.
  
  - Next use UFW to block HTTPS traffic to and from your machine.
    **Note**: Use the port number, _not_ the protocol name.
      
  - Use tcpdump to capture HTTPS traffic and then attempt to browse the web.
  
  - Stop the capture and open it with Wireshark.

  - Make sure it syncs up with your browsing experience.
