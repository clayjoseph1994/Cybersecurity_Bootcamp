# Real iptables

Before beginning please make sure to download the following file 
- [rules.tar](/./rules.tar)

## Instructions
- Extract the provided archive with: `tar xvf rules.tar`.

- Inspect `default.rules` and answer the following:
  - How many rule entries are registered on the firewall?
      - **Hint**: Look at the section marked `### RULES ###`
  >**Solution**: `default.rules` does not have any rules set. 
  - These are the iptable rules UFW sets _by default_—before you set anything yourself. Do these rules block/allow packets?
  
  >**Solution**: This file does not have any rules that block traffic. It only contains rules for logging.

- Inspect `apache.full.rules`. These rules are designed to allow access to an Apache web server.
  - Which ports do you expect to be open?
  > **Solution**: We would expect ports 80 and 443 to be open to allow HTTP and HTTPS traffic.
  - Find the rules providing/denying access to these ports.
  >**Solution**: `-A ufw-user-input -p tcp -m multiport --dports 80,443 -j ACCEPT -m comment --comment 'dapp_Apache%20Full'`
  - Do the iptables rules have built-in protections against users who make a large number of requests?
  >**Solution**: This rule does not have any protection against users that make a large number of requests. However, there is a logging rule that will log this type of activity.
  - > `-A ufw-logging-allow -j LOG --log-prefix "[UFW ALLOW] " -m limit --limit 3/min --limit-burst 10`

- Inspect `openssh.rules` and answer the following:
  - Which ports do you expect to opened?
  > **Solution**: `ssh` uses port 22.
  - Find the rules corresponding to these ports.
  > **Solution**: `-A ufw-user-input -p tcp --dport 22 -j ACCEPT -m comment --comment 'dapp_OpenSSH'`
  - Explain the rule(s) in detail. I.e., explain each flag. Use the output of `iptables --help`, as well as the documentation at: http://ipset.netfilter.org/iptables.man.html
  > **Solution**: `-A ufw-user-input -p tcp --dport 22 -j ACCEPT -m comment --comment 'dapp_OpenSSH'`
  > - `-A` - Append this rule to the list.
  > - `ufw-user-input` - This rule was added with ufw
  > - `-p tcp` filter for the `tcp` protocol
  > - `-dport 22` destination port 22 (ssh)
  > - `-j ACCEPT` Jump to Accept OR 'Accept the packet.'
  > - `-m comment` : `match comments` that come next
  > - `--comment 'dapp_OpenSSH'` : match the comment 'dapp_OpenSSH'. 
