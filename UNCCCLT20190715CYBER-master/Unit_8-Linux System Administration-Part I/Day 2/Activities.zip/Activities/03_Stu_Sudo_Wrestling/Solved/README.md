# Sudo Wrestling

Many job interviews will have you complete a technical interview. The following activity is designed to show case your knowledge about logs, and your investigative prowess.

**Scenario**

Working at our security firm we deal with many clients. Recently, one of our clients has reached out because their Network Intrution Detection System identified access to their server from a different country. They have passed you the following log and have asked you to investigate this attack. 

**Objectives**

Using terminal (**Mac**) or Git Bash (**Windows**) identify the following about the attack:

- Determine which user's account has been compromised
  > **Solution**: `sudo grep -a 'sudo' auth.log`
    - Should find "zeus : user NOT in sudoers"

  > - You can also see these entries at the bottom of the file by browsing the file with `cat` or `nano` or `less`, etc.

- Identify which user was attempting `sudo`
  > **Solution**: `zeus`

- What command did the compromised user try to run as sudo?
  > **Solution**: `sudo cp /etc/passwd /home`

- What advice would you give your client about dealing with the compromised account? What command would you use? What if the account that was compromised hasn't been used in years? How would you remove it?
  > **Solution**: Change that user's password, _or_ remove their account using the command `passwd zeus` _or_ `userdel zeus`
