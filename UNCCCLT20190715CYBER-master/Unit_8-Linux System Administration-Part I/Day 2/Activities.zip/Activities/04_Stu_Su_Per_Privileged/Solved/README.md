# Su-per Privileged

In this activity, you'll get a chance to crack user passwords, and then use `su` to run files you ordinarily don't have access to.

- Identify users who are members of `hackers`
 > **Solution**: run `groups <username>` for each user. You'll find that asgard, loki, poseidon, and zeus are members of `hackers`.

- Find the backup of `/etc/shadow` with "other" read permissions saved in one of their home folders.
  **Solution** `sudo find /home -iname *shadow*`

-
 Copy backed-up `shadow` and remove all members who are not `hackers`
  > **Solution**: `sudo cp /home/loki/shadow.bak .` 
  > - Then, use `sudo nano shadow.bak` to remove all users except asgard, loki, poseidon, and zeus.

Your file should look like:

```bash
poseidon:$6$hesyNlY9$G.<truncated>
zeus:$6$CNqChaaI$5k3/<truncated>
loki:$6$BIk4Yyiv$oSek8SJ/<truncated>
asgard:$6$iLmHS4Wf$p.<truncated>
```

- Use `john` to crack passwords in `shadow.bak`
  > **Solution**
  > ```bash
  > sudo john shadow.bak
  > ```

- Use the help command for john to `show` the passwords.
  > **Solution**: `sudo john --help`
  > - `sudo john --show shadow.bak`

- Use `su` to assume identity of another user
  > **Solution**: run `su loki` and enter the user's password: `ferrari`.

## Instructions

### Cracking Passwords

- What happens when you try to read `/etc/shadow`? Why does this happen?
   > **Solution**: You can't see `/etc/shadow`, because only `root` has permissions to read this file.

- Another user left a copy of `/etc/shadow` in their home directory. Find it.
   > **Solution**: `sudo tree <username>` or `sudo ls -aR <username>` OR `sudo find /home -iname *shadow*`
   > - You should find `/home/loki/shadow.bak`

- Create a new folder in your `Documents` directory, called `.hidden`, and change into it.
   > **Solution**: `mkdir ~/Docuents/.hidden`
   > - `cd ~/Documents/.hidden`

- Move the copied `shadow` file you found into `.hidden`, and change into `.hidden`.
   > **Solution**: `mv ~/shadow.bak .`

- There's a program called `john-the-ripper` on your VM. Run it using `sudo john` and pass the shadow file as argument.
   > **Solution**: `sudo john shadow.bak`

- What do you see when `john` finishes running? Record your response.
   > **Solution**:
   >   - poseidon:lakers:17933:0:99999:7:::
   >   - zeus:starwars:17933:0:99999:7:::  
   >   - loki:ferrari:17933:0:99999:7:::

- NOTE: `john` wont crack the password for `asgard`.

### Finding the Flag

- One of the users has a "flag" file somewhere in their home directory that is executable.
- Find out who, and what the path to the file is.
> **Solution**: `sudo find /home -iname 'flag'`

  - This raises a `Permission denied` error for a directory `.hidden` owned by `poseidon`...

- Use the passwords you just cracked to login as the user who owns the flag.
  - `su poseidon`
  - Use password: `lakers`

- Move into the directory you found, and run the flag file using `./` notation.
  - `cd /home/poseidon/.hidden`
  - `./flag`

- Your output should be:

```bash
$./flag
You found the flag!
```