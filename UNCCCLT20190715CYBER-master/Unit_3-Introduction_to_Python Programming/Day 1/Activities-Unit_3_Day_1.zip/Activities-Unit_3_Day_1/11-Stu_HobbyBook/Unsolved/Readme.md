
### Instructions:

  * Create a dictionary that will store the following:

    * Your name
    * Your age
    * A list of a few of your hobbies
    * A dictionary of the times you wake up during the week

  * Print out three statements: 
    * Hello I am (name) and I am a (occupation)
    * I have (number of) hobbies!
    * On the weekend I get up at (time)


  * Use the file provided to help you get started. 
