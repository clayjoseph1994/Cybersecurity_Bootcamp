# Dictionary full of info

# Print out results are stored in the dictionary
