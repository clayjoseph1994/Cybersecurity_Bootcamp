# Create a variable called user_name that captures the user's first name.


# Create a variable called neighbor_name that captures the name of the user's neighbor.


# Create variables to capture the number of months the user has been coding.


# Create variables to capture the number of months the user's neighbor has been coding.


# Use math to calculate the combined months coded between the two users. 
# Store this in a variable called total_months_coded.


# Print results in the form:
# I am <user_name> and my neighbor is <neighbor_name>
# Together we have been coding for <total_months_coded> months!

