## Down To Input

In this activity, you will create an application by gathering information from your neighbor and then running some code.

## Instructions

  * Create two different variables, `user_name` and `neighbors_name`, that will take the input of your first name and your neighbor's first name.

  * Create two more variables, `months_you_coded` and `months_neighbor_coded`, that will take the input of how many months each of you have been coding.

  * Create another `variable, months_neighbor_coded` that combines the total number of months that each of you have been coding. 

  * Print out the following two statements:
    *  The first should say `I am [user_name] and my neighbor is [neighbor_name]`.
    *  The second should say `Together we have been coded for total_months_coded`.
