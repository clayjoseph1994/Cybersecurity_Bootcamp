# Create a web address and store it in a variable


# Store the IP address within a string variable


# Create some variables to store how many times the site was visited each day






# Add up all of the daily hits for the week and store them in a variable


# Find the average daily hits for the week


# Print out all the summaries to the screen




