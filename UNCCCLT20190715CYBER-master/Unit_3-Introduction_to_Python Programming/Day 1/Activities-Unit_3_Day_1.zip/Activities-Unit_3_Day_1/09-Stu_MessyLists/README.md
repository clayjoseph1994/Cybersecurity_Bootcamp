# Messy Lists

In this activity,you are give a large list of IP addresses and will answer some basic questions based on its contents. Afterwards, you will add and remove IP addresses to and from the list.

## Instructions

 * Determine the length of the list and print the length out to the terminal.

  * Determine the indexes for the IPs "82.82.0.22" and "207.209.106.220" and then print the indexes out to the terminal.

  * Add the following IP addresses to the list:

      * "220.66.146.40"
      * "245.201.208.161"
      * "208.222.148.199"
      * "104.216.140.187"
      * "73.57.167.115"

  * Remove the following IP addresses from the list:

      * "53.239.114.76"
      * "65.136.121.223"
