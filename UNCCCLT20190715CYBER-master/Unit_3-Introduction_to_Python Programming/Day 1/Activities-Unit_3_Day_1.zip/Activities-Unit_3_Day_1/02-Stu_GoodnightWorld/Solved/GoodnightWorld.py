# Prints the phrase "Goodnight World!" to the terminal
print("Goodnight World!")
