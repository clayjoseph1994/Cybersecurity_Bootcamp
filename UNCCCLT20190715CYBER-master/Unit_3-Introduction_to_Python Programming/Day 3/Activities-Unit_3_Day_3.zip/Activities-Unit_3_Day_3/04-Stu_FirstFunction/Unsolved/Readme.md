## My Very First Functions

* In this activity, you are given a dictionary and will create three functions to print valuable information to the terminal.

### Instructions:
  
* Using the provided dictionary of names and social security numbers (SSNs), complete the following tasks:

    * Create a function that will loop through all of the keys in the dictionary and print them out one at a time.
    * Create a function that will loop through all of the values in the dictionary and print them out one at a time.
    * Create a function that will loop through all of the keys AND values in the dictionary and print them out one at a time.
      
  * **Hints:**
  
    * You will need to use loops within your functions.
    
    * The file we provided to you guides you step by step through the code you will have to create. Some of the code has also been filled in for you. 
    
    * Remember that you will need to call your functions to execute them.
