# Create an empty dictionary, called inventory
inventory = {}

# Ask the user how many items they have in their inventory
item_count = int(input("How many items do you have in your inventory? "))

# Use `range` and `for` to loop over each number up to the inventory number
for x in range(item_count):

    # Prompt the user for the name of an item in their inventory ("What's the item? ")

    
    # Prompt the user for the price of that item ("How much does it cost? ")

    
    # Put the item into the dictionary as the key, and associate it with its price

    # Creating separation between each new item prompt
    print("--------")

# Use `items` to loop through the dictionary and print the info to the screen


    # Check if the price of the item is less than five


        # If the price is less than five, print out "This item is on sale!"

        
    # Creating separation between each item
    print("--------")

