## Vulnerable List


### Instructions:

* Using the file provided, do the following: 

     * Create a loop using range() that moves through only the first 5 IP_addresses and prints them in order to the screen with their rank.

     * Create a loop using enumerate() that goes through all the IP_addresses and prints out the vulnerability ranking for each one.

* **Hint:** The *ranking* for an IP address is determined by its position in the list. The first element has the ranking of 1, the second has the rank of 2, and so on.


* We have provided the initial code for you in the script file. Use the comments to help you with the rest of the code.
