x = 1
y = 10

# == evaluates to True if the two values are equal
if (x == 1):
    print("x is equal to 1")

# != evaluates to True if the two values are NOT equal to each other
if (y != 1):
    print("y is not equal to 1")

# Checks if one value is less than another
if (x < y):
    print("x is less than y")

# Checks that one value is greater than another
if (y > x):
    print("y is greater than x")

# Checks that a value is less than or equal to another
if (x >= 1):
    print("x is greater than or equal to 1")

# If - Else statement
# The else block of code will only ever run when the if statement is False
if (x > 5):
    print("x is large")
else:
    print("x is small")

