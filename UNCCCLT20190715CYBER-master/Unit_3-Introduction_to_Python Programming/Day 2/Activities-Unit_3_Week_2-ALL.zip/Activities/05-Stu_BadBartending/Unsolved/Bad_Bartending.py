# Set a variable, called `drinking_age`, to 21
drinking_age = 21

# Prompt the user for their age
user_age = int(input("How old are you? "))

# Check if the user is 21 or older
if user_age >= 21:
    # If so, create a list, called `drinks`. Store four cocktails in it.
    
    
    
    # Prompt the user for the drink that they want to order

    
    # Check if the user's selection is in `drinks`
   
        # If so, print: `"Cheers!"`
  
    else:
        
        # Print: `"I don't know that one..."
       
else:
    # If not, print: "Your fake ID looks really fake."
  
