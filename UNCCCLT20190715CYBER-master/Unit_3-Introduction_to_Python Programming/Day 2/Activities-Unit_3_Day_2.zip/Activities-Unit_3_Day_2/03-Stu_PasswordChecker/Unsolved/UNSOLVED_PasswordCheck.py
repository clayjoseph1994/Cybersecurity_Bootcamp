# Master Username and Password
master_password = "password"

# Capture a user's password

# Check if the user's password matches the master_password. Inform user of outcome.





