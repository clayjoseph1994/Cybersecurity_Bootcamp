# Password Checker

* In this activity, you will create a command line application that asks users for their password. 

* If the password matches the value stored within the `master_password` variable, alert the user with a message stating: "You have been granted access!"

* If the password does not match the value stored within the `master_password`, alert the user with a message stating: "You have been denied access!"
