## Doling Out Data

### Instructions:

  * Declare a variable called `name` and store your name inside it.

  * Print the message: "My name is *YOUR NAME HERE*."

  * Declare a variable called `age` and store your age inside it.

  * Print the message: "I am *YOUR AGE HERE* years old."

  * Declare a variable called `pizza_price` and store a number inside it.

  * Declare a variable called `number_of_pizzas` and store a number inside it.

  * Store the total price for all the pizzas in a variable called `total_price_of_pizzas`.

  * Print the message: "The price of pizza is *PRICE OF PIZZA* dollars."

  * Print the message: "We are buying *NUMBER OF PIZZAS* pizzas."

  * Print the message: "The total price for all the pizzas is *TOTAL PRICE OF PIZZAS*."

  * Create a list, called `favorite_countries`. Store the name of four favorite countries inside it.

  * Print the message: "My favorite countries are *LIST OF COUNTRIES HERE*."

  * Create a dictionary called `contact_information` and store a home phone number, a cellphone number, and an email address inside of it.

  * Print out the message: "Please contact me at *EMAIL* or call me at *HOME PHONE*"

  * Print out the message: "In case of an emergency call *CELL NUMBER*"
  
  * **Use the script file provided to help you through your solution. We filled in the first few answers for you.**
