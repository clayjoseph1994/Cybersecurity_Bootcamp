# Declare a variable called `name`, and store your name inside it.
name = "<update with your name>"

# Print the message: "My name is <YOUR NAME HERE>"
print("My name is " + name + ".")

# Declare a variable called `age`, and store your age inside it.
age = 42

# Print the message: "I am <YOUR AGE HERE> years old."

print("I am " + str(age) + " years old.")


#######################################################

# Declare a variable called `pizza_price`, and store a number inside it.


# Declare a variable called `number_of_pizzas`, and store a number inside it.


# Store the total price for all the pizzas in a variable called `total_price_of_pizzas`.


# Print the message: "The price of a single pizza is $<PRICE OF PIZZA>."


# Print the message: "We are buying <NUMBER OF PIZZAS> pizzas."


# Print the message: "The total price for all the pizzas is <TOTAL PRICE OF PIZZAS>."



#######################################################
# Create a list called `favorite_countries`. Store the name of four favorite countries inside it.


# Print the message: "My favorite countries are: <YOUR LIST HERE>."


#######################################################
# Create a dictionary called `contact_information` and store a home phone number, a cellphone number, and an email address inside of it.





# Print out the message: "Please contact me at <EMAIL> or call me at <HOME PHONE>"



# Print out the message: "In case of an emergency call <CELL NUMBER>"


