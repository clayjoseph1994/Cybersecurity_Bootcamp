## Bad Bartending 

* In this activity, you will create a digital bartender. This application will first ask the user for their age in order to determine if the user can be served drinks and then will ask for the user's order. If the order is in the known list of drinks, it will then print "Cheers!" to the terminal.


### Instructions

* Set a variable called `drinking_age` to 21.

* Prompt the user for their age in years and then check if the user is 21 or older.

   * If the user is 21 or older, create a list called `drinks` and store the names of 4 cocktails inside of it. Then prompt the user for the drink they want, check if the user's selection is in the`drinks` list, and print "Cheers!" to the terminal if it is.
   
* If the user is not 21 or older, print "your fake looks really fake" to the terminal instead.
      
* Use the script file provided to get started. We have provided you with the initial code as well as some important pieces throughout. Use the comments to help you with the rest of the code.
