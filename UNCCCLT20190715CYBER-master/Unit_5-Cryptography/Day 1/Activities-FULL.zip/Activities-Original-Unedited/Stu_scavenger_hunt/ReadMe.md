## Character-Encoding Scavenger Hunt

**Instructions:**

Convert the following:
 
  ```
  57 65 6c 63 6f 6d 65 20 74 6f 20 74 68 65 20 73 63 61 76 65 6e 67 65 72 20 68 75 6e 74 21 20 47 6f 20 74 6f 20 74 68 65 20 66 6f 6c 6c 6f 77 69 6e 67 20 77 65 62 73 69 74 65 3a 0a 68 74 74 70 3a 2f 2f 77 77 77 2e 70 61 67 65 6f 72 61 6d 61 2e 63 6f 6d 2f 3f 70 3d 73 65 63 72 65 74 34
  ```

