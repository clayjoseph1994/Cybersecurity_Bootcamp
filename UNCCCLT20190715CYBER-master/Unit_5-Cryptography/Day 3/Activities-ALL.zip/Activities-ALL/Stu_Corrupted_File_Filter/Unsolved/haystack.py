# Package imports
import hashlib
import os

# Hash of original file
hash = "6341ee17b7cd8ef719d1c236cc54c3b06b043d11f399d45fca2dbf09eb55fa6f"

# TODO: Get relative path to target directory using `input`

# TODO: Loop over files in target direc using `os.listdir`
    # TODO: Create path to file: path + "/" + filename

    # TODO: Open file in "rb" mode
        # TODO: Get file contents

        # TODO: Hash the file using sha256

        # TODO: Compare to original hash
    