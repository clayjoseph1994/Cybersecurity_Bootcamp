import hashlib

# TODO: Open a file to hash in "rb" mode

    # TODO: Store the file contents in a variable
    # TODO: Create MD5 and SHA256 objects
    # TODO: Generate the hexdigests of the file contents
    # TODO: Print the hexdigests to the terminal
