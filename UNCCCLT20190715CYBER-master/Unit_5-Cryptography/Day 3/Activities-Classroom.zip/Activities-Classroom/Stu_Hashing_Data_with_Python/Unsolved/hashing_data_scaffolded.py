import hashlib

# TODO: Open a file to hash
with open("./hash_me", "rb") as file:
    # TODO: Store the file contents in a variable
    contents = file.read()

    # TODO: Create MD5 and SHA256 objects

    # TODO: Generate the hexdigests of the file contents

    # TODO: Print the hexdigests created above to the terminal
