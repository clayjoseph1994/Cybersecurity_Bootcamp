# Exploring Snort
In this exercise, you'll explore a Snort installation to:
- Familiarize yourself with Snort's directory structure
- Inspect the Snort configuration file
- Examine Snort community rules

---

## Instructions
### The Snort Configuration File
Begin by moving into `/etc/snort`. Then, answer the questions below.
- List the three directories in `/etc/snort`, and explain what each is for.
  > **Solution**
  >   - `preproc_rules`: Contains preprocessor rules.
  >   - `rules`: Contains rules files.
  >   - `so_rules`: Contains Shared Object rules.

- Run: `grep -in step snort.conf`. 
  - How many steps are there to configuring Snort?
  > **Solution**: There are 9 steps:

  ```bash
  root@4f489d942436:/etc/snort/etc# grep -in step snort.conf
  27:# You should take the following steps to create your own custom configuration:
  41:# Step #1: Set the network variables.  For more information, see README.variables
  113:# Step #2: Configure the decoder.  For more information, see README.decode
  186:# Step #3: Configure the base detection engine.  For more information, see  README.decode
  238:# Step #4: Configure dynamic loaded libraries.
  252:# Step #5: Configure preprocessors
  510:# Step #6: Configure output plugins
  534:# Step #7: Customize your rule set
  663:# Step #8: Customize your preprocessor and decoder alerts
  673:# Step #9: Customize your Shared Object Snort Rules
  ```

- Open `snort.conf` in nano. Scroll down to Step 1.
  - What kind of information do you configure in Step 1?
  - How would you configure Snort to protect the home network `192.168.1.0/24`? 
  > **Solution**: Run `nano +41 snort.conf`. 

  ```bash
    # Step 1: Set the network variables. 
    ####################################

    # Setup the network addresses you are protecting
    ipvar HOME_NET 192.168.1.0/24
  ```
  
  You'd protect the home network by setting `ipvar HOME_NET 192.168.1.0/24`

- Scroll down to Step 7.
  - How do you add rules to Snort?
  - Which rules are included by default?
  - Edit the file to include `local.rules` and exclude `sql.rules`.
  > **Solution**
  >   - You add rules to Snort by removing the `#` next to a rule path. The rules that are referenced must have a corresponding file in the `/etc/snort/rules` directory.
  
  ```bash
    # Step 7: Customize your rule set
    # For more information, see Snort Manual, Writing Snort Rules
    # 
    # NOTE: All categories are enabled in this conf file
    ####################################################

    # site specific rules
    
    include $RULE_PATH/sql.rules
    include $RULE_PATH/community.rules
    #include $RULE_PATH/local.rules

    # include $RULE_PATH/app-detect.rules
    # include $RULE_PATH/attack-responses.rules
    # include $RULE_PATH/backdoor.rules
    # include $RULE_PATH/bad-traffic.rules
    ...<scroll>
    ...<scroll>
    ...<scroll>
    # include $RULE_PATH/protocol-finger.rules
    # include $RULE_PATH/protocol-ftp.rules
    include $RULE_PATH/protocol-icmp.rules
    # include $RULE_PATH/imap.rules
    # include $RULE_PATH/nntp.rules
  ```

  >   - This configuration includes `local.rules`, `community.rules` and `protocol-icmp.rules` by default. 
  >  - Include `local.rules` by un-commenting it's line, so it reads: `include $RULE_PATH/local.rules`.
  > - Exclude `sql.rules` by commenting that line out.

    ```bash
    #include $RULE_PATH/sql.rules
    include $RULE_PATH/community.rules
    include $RULE_PATH/local.rules
    ```

### Inspecting Rules
- Navigate to `/etc/snort/rules`.
  - How many lines are in the files `local.rules`, `community.rules`, and `sql.rules`?

  **Solution**
    `$ wc -l {community,local,sql}.rules` OR `$ wc -l community.rules local.rules sql.rules`

    Output should be:

    ```bash
    3773 community.rules
    27 local.rules
    107 sql.rules
    3907 total
    ```

- Run the following command to print the last rule in each file:
  - `tail -n 1 {local,sql,community}.rules`

  ```bash
  $ tail -n 1 {local,sql,community}.rules
  ==> local.rules <==
  alert tcp any 6667 -> any any (msg:"C&C Server sent download command";content:"!download";sid:1000009;)

  ==> sql.rules <==
  alert tcp $HOME_NET any -> $EXTERNAL_NET $HTTP_PORTS (msg:"SQL PK-CMS SQL injection attempt"; flow:to_server,established; content:"/default.asp?"; fast_pattern; nocase; http_uri; content:"pagina="; distance:0; http_uri; pcre:"/pagina=[^&]*\x27/Ui"; metadata:service http; refrence:url,github.com/buddhaLabs/PacketStorm-Exploits/blob/master/1309-exploits/pkcms-sql.txt; classtype:web-application-attack; sid:32768; rev:1;)

  ==> community.rules <==
  alert tcp $HOME_NET any -> $EXTERNAL_NET $HTTP_PORTS (msg:"MALWARE-CNC Win.Downloader.XAgent variant outbound connection"; flow:to_server,established; content:"&itwm="; fast_pattern:only; http_header; metadata:impact_flag red, policy balanced-ips drop, policy max-detect-ips drop, policy security-ips drop, ruleset community, service http; reference:url,www.virustotal.com/file/b814fdbb7cfe6e5192fe1126835b903354d75bfb15a6c262ccc2caf13a8ce4b6; classtype:trojan-activity; sid:48140; rev:1;)
  ```

- For each rule you see, identify the following:
  - What **action** does snort take when it matches this rule's pattern?
  
    **Solution**: Each rule starts with the `alert` action.
  
  - Which **protocol** does each rule watch for?
 
    **Solution**: Each rule watches for the `tcp` protocol
  
  - What are the source/destination addresses the rule monitors?
  
    **Solution**: 
    - local.rules: `any 6667 -> any any`
      - The rule from the local.rules file is monitoring `any` source IP using port `6667`, going to `any` IP on `any` port. 
    - {community,sql}.rules: `$HOME_NET any -> $EXTERNAL_NET $HTTP_PORTS`
      - The rules from the sql.rules _and_ the community.rules files are both monitoring _all_ computers on the `$HOME_NET` on `any` port, going to any machine on the `$EXTERNAL_NET` over any ports in the `$HTTP_PORTS`. 
    
    - REMINDER: The variables $HOME_NET and $HTTP_PORTS are defined in the snort.conf configuration file.
  
- What kind of activity does each rule monitor for (e.g., command and control messages in the packet? embedded viruses? etc.)

  **Solution**:
    - The rule from local.rules is looking for 'Command and Control' server activity. Specifically a `download` command.
    - The rule from sql.rules is is looking for 'SQL Injection' attempts. 
    - The rule from community.rules is looking for outbound connectioins to a 'Command and Control' server.