# Creating Rules
In this exercise, you'll write Snort rules and test them against live traffic.

## Instructions

**Note**: After writing each rule, start Snort, then inspect the Snort `alert` file to check that it was fired.

---

- Open `local.rules` in nano.
  
**Solution**

  >`nano /etc/snort/rules/local.rules`

- Comment out all of the existing rules. 
- Add the rules described below:
  - Write a rule that detects telnet traffic from the public Internet to the local subnet.
  - Write a rule that detects an attacker running a tcp scan on any port.
    - **Hint**: Be sure to specify the correct destination port(s).
  
**Solutions**
  > ```bash
  > alert tcp $EXTERNAL_NET any -> any 23 (msg:"Telnet packet detected!";sid:2000000;)
  > alert tcp any any ->  any any (msg: "Possible TCP scan";sid:10000004;)
  > ```
