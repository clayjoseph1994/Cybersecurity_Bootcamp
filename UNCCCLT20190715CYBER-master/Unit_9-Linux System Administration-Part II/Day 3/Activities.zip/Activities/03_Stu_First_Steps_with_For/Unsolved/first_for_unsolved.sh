#!/bin/bash

# 1. Print "Moe", "Larry", and "Curly"

# 2. Print "I've used Mac OSX"; "I've used Windows"; and "I've used Linux"

# 3. You do NOT need to change this block. Just run it. Then, answer: What does `*` mean?
for FILE in *
do
  echo "$FILE"
done

# 4. Run: `seq 1 10`. What does this print?

# 5. Use command expansion and `seq` to print every number between 1 and 24.
