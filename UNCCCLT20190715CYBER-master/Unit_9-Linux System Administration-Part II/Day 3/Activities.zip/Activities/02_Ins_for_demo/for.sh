#!/bin/bash

for NAME in "Moe" "Larry" "Curly"
do
  echo "Hello, $NAME!"
done