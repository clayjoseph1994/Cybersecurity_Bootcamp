#!/bin/bash

for NAME in $(cat names.txt)
do
  echo $NAME
done