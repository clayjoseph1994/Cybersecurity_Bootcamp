# XSS Review

## Questions

### Breaking Syntax

Consider the HTML below.

  ```html
  <img src="http://placeholder.it/200x200x" style="border: 1px solid blue;" />
  ```

Suppose the user profile page allows users to type a color to use for the border color. For instance, a user could enter `red` in a form, which would change the above HTML to:

  ```html
  <img src="http://placeholder.it/200x200x" style="border: 1px solid red;" />
  ```

Alternatively, you could set it to something invalid:

  ```html
  <img src="http://placeholder.it/200x200x" style="border: 1px solid NOT A COLOR!;" />
  ```

Use the ability to update the border color to inject an XSS payload that causes an alert box to pop up when the user mouses over the image.
- Which HTML event attribute should you use? Refer to: <https://www.w3schools.com/tags/ref_eventattributes.asp>

> **Solution**: One of several possible answers : `red;"onmouseover="alert(1)"><!--`.

### Mitigation

Explain two different strategies for patching the above vulnerability.

> **Solution**
>  - The developer could constrain the user's choices by presenting a list of available colors, rather than letting them set the color arbitrarily.
>  - Alternatively, you could remove special characters like `"`, `'`, `;`, etc., from the user's input before dumping it to the page.
