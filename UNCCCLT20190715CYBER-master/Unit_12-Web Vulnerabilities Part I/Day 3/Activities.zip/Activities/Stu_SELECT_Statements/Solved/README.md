# SELECT Queries and WHERE Clauses

The solution for the exercise below is available at: <https://www.db-fiddle.com/f/t86qHZKSwyCBt6HD2BEXWM/1>

## Instructions

- Write a SELECT statement that retrieves all data from the database.

- Write a SELECT statement that retrieves the `name` and `severity` from all records.

- Write a SELECT statement that retrieves the record with `id` 2.

- Write a SELECT statement that retrieves the record with `severity` of `High`.

- DELETE the record with `id` 2.

- DELETE the record with `name` `usermod_script`.

- SELECT all remaining records
