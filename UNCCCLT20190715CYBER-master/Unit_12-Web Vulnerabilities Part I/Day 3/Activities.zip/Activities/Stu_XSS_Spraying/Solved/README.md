# XSS Injection Spraying

## Instructions

### XSS Spraying without Filters

- Navigate to tab `DVWA Security`, and set your security level to **Low**.

- In Burp, turn on the Interceptor.

- Navigate to `XSS (Reflected)`, and send the intercepted request to Intruder.

- Download the form that was provided to you and create a new text document called `xss_payloads.txt. 

- Use Intruder on Burp Suite to send the payloads in `xss_payloads.txt` to the web form. Pause the attack after 50 injections were used. 
  
- Review the responses to your attack. 
  - Can you demonstrate that this payload actually results in JavaScript execution on the client?
    - `Solution: Yes, by copying the command that worked and placing it into DVWA input box`

- Keep track of the XSS payloads that were successful. You'll need them for the next exercise.

### XSS Spraying against Filters

- Navigate to tab `DVWA Security`, and set your security level to **High**.

- Run your XSS spray again. Did any payloads work? Why or Why not?
    - `Solution: Yes, beause we are still injecting code that DVWA is susceptible to.`
   
### List three ways a web developer could protect their websites

- `Solution: Input sanitization, testing, and attribute escapes`
