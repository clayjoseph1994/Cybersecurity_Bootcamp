# Setting Up

In this exercise, you will set up DVWA for the day's exercises. Then, you'll verify that your Foxy Proxy and Burp Suite installations behave as expected.

_**Warning**_ The Ubuntu VM may ask if you would like to update to a newer version of Burp Suite, **do not upgrade the current version of Burpsuite configured on the VM.** Newer versions do contain the Spider and Scanner feature required for activities in class. If you did upgrade, please uninstall Burp Suite from the VM and download the older version [v1.7.36](https://portswigger.net/burp/releasesarchive/community). Alternatively, you can also save the state of the virtual machine at any point by taking a snapshot. While the machine is running, use the `Machine` dropdown menu and select `Take Snapshot`. Make sure to fill out the name and description in case you save multiple snapshots of a machine. This way you can restore your machine to a previous state if you accidentally happen to hit the `update` button in the future for Burp Suite.

## Instructions
- Launch DVWA by opening a terminal and running: `start_dvwa`.
- Open Firefox, and navigate to: `http://localhost`.
- Login with the credentials below.
  - **Username**: `admin`
  - **Passwodr**: `password`
  - **Create/Reset** the database, then log in again.
- Launch Burp Suite, 
- Configure the proxy on Firefox:
  - Click on `FoxyProxy` then `Options`
  - Click `Add` and fill in the following:
    - **Title or Description** = BurpSuite
    - **IP address, DNS name, server name** = 127.0.0.1
    - **Port** = 8080
  - Click `Save`
  - Click on `FoxyProxy` then `Use proxy BurpSuite for all URLs (ignore patterns)`

- Navigate to **DVWA Security**. Verify that Burp Suite intercepts your request (you don't have to do anything with it yet—just make sure the interceptor is working).
  - if so, copy the request into slack to share what you captured!
