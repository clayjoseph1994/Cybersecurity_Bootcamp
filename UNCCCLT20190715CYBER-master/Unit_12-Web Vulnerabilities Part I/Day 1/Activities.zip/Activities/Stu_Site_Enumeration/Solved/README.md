# Site Enumeration

## Instructions

### Enumerating with Burp 

- Browse to `localhost`.

- Click the **Target** tab in Burp Suite, and find `localhost` in the **Site map** column on the left.

- Return to the browser, and click around the site a bit. Return to Burp Suite and inspect the site map.

- Spider the site, and inspect the resulting site map. 
  - Do you notice any pages on the site that the spider didn't find?
  - Did you notice any pages that you missed but the spider _did_ find?

- Inspect the site map. Use the **URL** column to identify the URLs for the following:
  - Pages that might be vulnerable to injection attacks via GET query parameters.
      > **Solution**: The following URLs stand out.
      >   - `/instructions.php` (query param: `doc`)
      >   - `/security.php` (query params: `phpids` )
      >   - `/vulnerabilities/fi` (query param: `page`)
      >   - `/vulnerabilities/xss_r` (query param: `name`)


  - Pages that might be vulnerable to injection attacks via POST body.
      > **Solution**: The following URLs stand out.
      >   - `/vulnerabilities/csp`
      >   - `/vulnerabilities/exec`
      >   - `/vulnerabilities/setup`
      >   - `/vulnerabilities/sqli`
      >   - `/vulnerabilities/sqli_blind`
      >   - `/vulnerabilities/upload`
      >   - `/vulnerabilities/weak_id`
      >   - `/vulnerabilities/xss_s`
