# Replaying Requests with Repeater

In this exercise, you'll practice
- Using Burp Repeater to resend requests with different parameters
- Manipulating cookies to change an application's behavior

## Instructions

- Navigate to any vulnerability in DVWA.

- Turn on Burp Interceptor, and reload the page. Inspect the intercepted request.
  - Which cookies do you see?
    > **Solution**: DVWA sets `PHPSESSID` and `security` cookies.

- Send the intercepted request to Repeater. Then, forward it as-is. 
    > **Solution**: Press `Action` then scroll down and click `Send to Repeater`; click the **Repeater** tab; then click **Go**.

- Inspect the response. What is the **Security Level** of DVWA, based on the response?
    > **Solution**: The security level should be medium by default.

- Use Repeater to set the security level to `impossible`, and use the response to determine if your "hack" was successful.
    > **Solution**: In repeater, change `security=medium` to `security=impossible`. 
