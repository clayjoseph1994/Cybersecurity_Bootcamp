# Option 2 (Bonus)
# --------------------------------
# Create the Archive folder
mkdir Archive

# Combine the files in TodaysLog and output to Archive
cat TodaysLog/* > Archive/09_15_18.txt

# Navigate to Archive
cd Archive

# View archived result
less Archive