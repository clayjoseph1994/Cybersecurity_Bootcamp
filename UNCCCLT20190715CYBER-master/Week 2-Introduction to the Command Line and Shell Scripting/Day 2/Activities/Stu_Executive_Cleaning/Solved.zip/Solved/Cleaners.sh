# Create a new folder called Sorted_Gibberish
mkdir Sorted_Gibberish

# Create subfolders in Sorted_Gibberish
mkdir Sorted_Gibberish/Docs Sorted_Gibberish/Data Sorted_Gibberish/Text

# Search for all Word files and copy to Docs folder
find . -type f -iname *docx* -exec cp {} Sorted_Gibberish/Docs \;

# Search for all Excel files and copy to Data folder
find . -type f -iname *xlsx* -exec cp {} Sorted_Gibberish/Data \;

# Search for all text files and copy to Text folder
find . -type f -iname *txt* -exec cp {} Sorted_Gibberish/Text \;

# Bonus
# -------------------------------------------------------------

# Create a folder called LargeFiles
mkdir Sorted_Gibberish/LargeFiles

# Search for all large files (>200 KB) and move to the folder called Sorted_Gibberish/LargeFiles 
find . -type f -size +200 -exec mv {} Sorted_Gibberish/LargeFiles \;
