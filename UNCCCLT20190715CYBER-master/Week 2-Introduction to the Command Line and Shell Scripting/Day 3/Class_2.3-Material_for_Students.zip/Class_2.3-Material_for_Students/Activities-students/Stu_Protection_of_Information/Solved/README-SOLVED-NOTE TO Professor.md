# Protection of Information

No reference solutions, as this is a student-driven exercise. 

But, instructors should create a copy of the following slide, and add students' slides as they submit them: <https://docs.google.com/presentation/d/1mDsSHH6aA4bTwoIggze1a_dXpfAv47EFKCQ-AqdQxp8/edit?usp=sharing>
