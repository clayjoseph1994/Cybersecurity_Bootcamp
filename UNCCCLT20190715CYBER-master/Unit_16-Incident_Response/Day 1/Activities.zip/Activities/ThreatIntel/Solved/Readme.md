### Direct Instruction: Threat Intelligence Review

- Follow along through the solution file below.
  - **File** [Activities/ThreatIntel/Solved/Readme.md](Activities/ThreatIntel/Solved/Readme.md)

#### Instructions

- Facilitate a discussion about the threat bulletins that the students created.

- Ask if anyone would like to share their bulletin with the class. If the students are shy, call on a few students to share their bulletin with the class.

- For each student's bulletin, as a few of the following questions:
    - What insights were gained?
    - What recommendations would they make for their company?
    - What was the risk rating they gave for their respective company and why?  
