#!/bin/bash

for USER in $(ls /home); do
  id $USER
done
