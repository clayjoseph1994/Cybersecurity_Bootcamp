#!/usr/bin/env bash

# Install mysql
sudo apt install mysql-server

# Run through configuration steps...
# Document your credentials!
mysql_secure_installation
