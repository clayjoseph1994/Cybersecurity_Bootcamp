#!/usr/bin/env bash

# Install mysql
sudo apt install mysql-server

# Run through configuration steps...
# Document your credentials!
sudo mysql_secure_installation
