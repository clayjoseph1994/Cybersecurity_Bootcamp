# Installing Apache

- Install Apache using `apt`.
  - Solution: `apt install apache2`

- The next step is to update the Apache configuration with a `ServerName`. For our purposes, the `ServerName` should be your VM's private IP address. 

- Run `ifconfig`, and add the line: `ServerName 127.0.0.1` to the end of the file `/etc/apache2/mods-enabled/dir.conf`. 
  - **Note:** In a real enviroment you would want to use a static IP address. Because we are using a virtulized enviroment we will want the traffic to come back to the Apache server instead of a nonexistent IP.


- Verify configuration
    - Solution: `sudo apache2ctl configtest`

- Restart Apache
  - **Hint**: Use `sudo service apache2 restart` to restart. 

- Ensure the server starts on boot.
  - Solution: `sudo update-rc.d apache2 defaults`

- Next, update your UFW rules to use the `Apache Full` security profile. 

```
Solution: Run the following commands:
  - sudo ufw list
  - sudo ufw allow 'Apache Full'
  - sudo ufw status
  - sudo ufw enable
```


- Use cURL to send a GET request to `http://localhost/index.html`. You should see HTML!
  - Solution: `curl localhost`
