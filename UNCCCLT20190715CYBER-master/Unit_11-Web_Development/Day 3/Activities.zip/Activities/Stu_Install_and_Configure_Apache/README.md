# Installing Apache

- Install Apache using `apt`.


- The next step is to update the Apache configuration with a `ServerName`. For our purposes, the `ServerName` should be your VM's private IP address. 

- Add the line: `ServerName 127.0.0.1` to the end of the file `/etc/apache2/mods-enabled/dir.conf`. 
  - **Note:** In a real enviroment you would want to use a static IP address. Because we are using a virtulized enviroment we will want the traffic to come back to the Apache server instead of a nonexistent IP.

- Verify configuration

- Restart Apache
  - **Hint**: Use `sudo service apache2 restart` to restart. Figure out how to enable on startup yourself.

- Ensure the server starts on boot.

- Next, update your UFW rules to use the `Apache Full` security profile. 

- Use cURL to send a GET request to `http://localhost/index.html`. You should see HTML!
