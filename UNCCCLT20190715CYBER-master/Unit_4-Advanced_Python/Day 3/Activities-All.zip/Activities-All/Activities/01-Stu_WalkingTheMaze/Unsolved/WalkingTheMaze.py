# import the os library to use later
import os

# Create the file path
folder_path = os.path.join("TheMaze")

# Walk through all of the files contained within "TheMaze" directory
for root, dirs, files in os.walk(folder_path):

    # Loop through the files within the current root
   
   
        # Add some separation between the text that will be printed this time and the next
        print("---------------")

        # Create the path to the current file
       
       
        # Create a connection to the file in read mode
     
        # Read in the text of the current file
  

        # Print out the location of the file found
 

        # Print out the text that was inside of the file
 
