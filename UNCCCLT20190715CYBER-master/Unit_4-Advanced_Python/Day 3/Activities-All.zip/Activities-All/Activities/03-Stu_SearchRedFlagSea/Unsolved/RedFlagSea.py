# Import the two modules that will be used in this code

import os
import datetime

# Since there are so many files, os.walk would be wise
for root, dirs, files in os.walk('Text'):

    print("GETTING FILE INFO")
    
    # Loop through all of the files in the current root


        # Create the path to the current file
       

        # Get the stats on the file, save to fileInfo variable


        # Collect the last time at which the file was modified


        # Change the format of timeModified to datetime format


        # Collect the file size of the file


        # Print out the file name timestamp, and size to the screen
 

