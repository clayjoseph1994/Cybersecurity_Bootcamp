# Import the zipfile module into the application


# Create another reference, this time to a locked ZIP file


# Variable used to store the password string


# Run the `.extractall()` function with a password

