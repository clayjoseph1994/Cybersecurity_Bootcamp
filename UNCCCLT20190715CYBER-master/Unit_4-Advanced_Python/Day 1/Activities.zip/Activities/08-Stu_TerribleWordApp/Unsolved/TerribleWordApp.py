# Set the variable continueWriting to "y" to start things off

# Establish a connection to "Notes.txt" and set the mode to "write"


# Check if the user would like to write some more text to the page
 

    # Ask the user to enter some text and save it to a variable
  
    # Use notesFile.write() to push the text in the above variable to the external file


    # Add a newline character after the entered text

    # Ask the user if they would like to write another line
    
