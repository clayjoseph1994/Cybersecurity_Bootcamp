# Create a function that will ask what the user wants to do, and returns the user's choice back to the main program/file. 

    

# Create a function that will read the external file and print out the data it contains. Remember to split the text as this is a CSV file.Close the connection to your external file at the end.

   

# Create a function that will write a new row of data into the external file, but will not overwrite what is already there. This will require you to also collect that input from the user. When writing to your file, rememer to add in the necessary commas and line break. 


# Collect the user's initial choice


# Run a while loop that includes how the program will as long as the user selects either the Read or Write choice. so long as the user's choice is "1" or "2"


# Print out "THANK YOU FOR USING THE WATCHLIST"
