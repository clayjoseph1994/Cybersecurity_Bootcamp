# Ask the user for a color and save it to a variable


# Check that the color entered is one of the colors with an associated file

# Create a connection to the file that the user entered
# Since the files are all in the "Colors" folder the path should be "Colors/<Input>.txt"

# Read in the text contained within the colorFile

# Close the connection to the colorFile

# If there is no file associated with the color entered then print out an apology to the screen
