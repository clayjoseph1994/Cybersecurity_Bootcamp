# Create a function which takes in a word and then searches for the word within the text


    # Open up the file called "Monologue.txt"
    
    # Read the text contained within the file
  

    # Add a space before the word so as to make sure that it is independent


    # Search for any instances of the word provided
   

        # If the word is found, count up how many times it appears by splitting the text on the word and counting the length of the list returned
     

        # Print out how many times the word was found
       
    
    # If no instances of the word was found, print out that the word is not in the text
    else:
      

# Collect a word from the user


# Pass the word to search into the function created
