# Import the module that stores string data
import string

# Collect and print out all ascii letters - lowercase and uppercase

# Collect and print out all of the numeric digits

######################

# Import the module that can generate random numbers

# Collect and print out a random integer between 1 and 10

# Randomly shuffle the below list and print it to the terminal

######################

# Import the module used for hashing messages

# Collect and print out all of the available hashing algorithms