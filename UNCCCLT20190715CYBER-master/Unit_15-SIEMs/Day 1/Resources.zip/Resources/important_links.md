### Helpful Documentation

## Installation
- http://www.splunk.com/download
- http://docs.splunk.com/Documentation/Splunk/latest/Installation/Chooseyourplatform 

## Get Apps
- https://splunkbase.splunk.com/

## Help
- http://docs.splunk.com/Documentation http://answers.splunk.com/ http://blogs.splunk.com/ http://wiki.splunk.com/

## Understanding Configuration Files
- http://docs.splunk.com/Documentation/Splunk/latest/Admin/Aboutconfigurationfiles

## Understanding Buckets
- http://wiki.splunk.com/Deploy:UnderstandingBuckets

## Configuring Forwarder Inputs
- http://wiki.splunk.com/Where_do_I_configure_my_Splunk_settings

## Forwarding Resources
- http://docs.splunk.com/Documentation/Splunk/latest/Data/Usingforwardingagents
- http://docs.splunk.com/Documentation/Splunk/latest/Forwarding/Deploymentoverview 
- http://wiki.splunk.com/Deploying_Splunk_Light_Forwarders

## Splunk Event Timestamp Processing
- http://docs.splunk.com/Documentation/Splunk/latest/Data/HowSplunkextractstimestamps
 
