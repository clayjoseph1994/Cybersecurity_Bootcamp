## SIEMS Day 1:  Guided Practice - Vendor Review 
--------

## Instructions 

* Break out into groups of 2-3 students

* Use Google to research 3-5  SIEM vendors (besides Splunk) 

* List the following information: 

	* Company Name 

	* Product Name 

	* Capabilities (Advantages/Disadvantages)

**Great job ... Activity Complete!**