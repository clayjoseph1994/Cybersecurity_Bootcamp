**Instructions with Annotated Solutions**

- Note that the target machine is running Windows XP, and is running MS-RPC on port 135. Many Windows XP machines are vulnerable to [MS08-067](https://support.microsoft.com/en-us/help/958644/ms08-067-vulnerability-in-server-service-could-allow-remote-code-execu), a critical vulnerability in MS-RPC that allows attackers to achieve remote code execution (RCE). Before using the module to exploit the target, read about the vulnerability at the provided link, and answer the questions below.
  - What can an attacker achieve by exploiting this vulnerability?
  - Which systems are vulnerable?
  - What happens if an exploit attempt fails? How might this affect your attempts to compromise the machine?

  **Solutions**:
  >   - Attackers can achieve arbitrary remote code execution (RCE), which potentially allows them to take over the vulnerable host completely.
  >   - Windows 2000, XP, and Server 2003 are vulnerable.
  >   - Failed exploit attempts might crash the service. This could result in your being unable to exploit this service (if it doesn't restart). It could also reveal your presence to administrators, as a crash could shut down file, printer, and named pipe sharing on the network.

- Attach to the session you've opened on the victim. Use Meterprter and the `post/windows/gather/win_privs` module to gather the following information:

  - User ID and username

  - Machine privileges and access controls

  - Network interfaces

  - **Hint**: After connecting to your Meterpreter shell, use the command `background` to return to `msfconsole`. Then, you can use `post/windows/gather/win_privs`.

  **Solutions**:
  > ```bash
  > msf > sessions -i 1
  > meterpreter > getuid
  > meterpreter > ifconfig
  > meterpreter > getprivs
  > meterpreter > background
  > msf > use post/windows/gather/win_privs
  > msf > set session 1
  > msf > run -j
  > ```


- Answer the following questions about your target to complete your enumeration:

  - What privilege level does your compromised user have?

  - Is UAC enabled?

  - Which subnets is your victim attached to?

  **Solutions**:
  >   - The compromised user has SYSTEM privileges.
  >   - UAC is _not_ enabled.
  >   - The victim is attached to `10.10.10.0/24` and `172.16.0.0/24`.
  > Note that the logical next step is to pivot into the `172.16.0.0/24` subnet.
