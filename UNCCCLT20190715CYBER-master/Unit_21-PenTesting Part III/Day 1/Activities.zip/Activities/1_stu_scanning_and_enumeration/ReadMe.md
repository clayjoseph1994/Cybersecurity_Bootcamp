## Scanning and Enumeration with Metasploit

**Instructions**

  - Follow the instructions in **Part 1: Identify the Vulnerable Windows System**.

  - Note that the target machine is running Windows XP and is running MS-RPC on port 135. Many Windows XP machines are vulnerable to [MS08-067](https://support.microsoft.com/en-us/help/958644/ms08-067-vulnerability-in-server-service-could-allow-remote-code-execu), a critical vulnerability in MS-RPC that allows attackers to achieve remote code execution (RCE). Before using the module to exploit the target, read about the vulnerability at the provided link, and answer the questions below.

    Link: https://support.microsoft.com/en-us/help/958644/ms08-067-vulnerability-in-server-service-could-allow-remote-code-execu

    - What can an attacker achieve by exploiting this vulnerability?

    - Which systems are vulnerable?

    - What happens if an exploit attempt fails? How might this affect your attempts to compromise the machine?

  - Next, follow the instructions in **Part 2: Exploit the Vulnerable System**, from steps **1. Search for `netapi` Exploit** to **10. Background your Meterpreter Session**.

  - After following the instructions above, follow the additional steps below.

- Attach to the session you've opened on the victim. Use Meterprter and the `post/windows/gather/win_privs` module to gather the following information:

  - User ID and username

  - Machine privileges and access controls

  - Network interfaces  

    - **Hint**: After connecting to your Meterpreter shell, use the command `background` to return to `msfconsole`. Then, you can use `post/windows/gather/win_privs`.

- Answer the following questions about your target to complete your enumeration:

  - What privilege level does your compromised user have?

  - Is UAC enabled?

  - Which subnets is your victim attached to?
