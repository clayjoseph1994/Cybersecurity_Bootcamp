## Dumping Credentials and Passing the Hash

**Note:** This has to be completed in the same terminal window, where you had set up `autoroute`. 

**Instructions**:

  - Follow the instructions in **Part 2: Exploit the Vulnerable System**, from steps **11: Use `hashdump`** up to step **26**.

  - **Do Not complete steps 26 - 34 in class as they start a scan that may take too long. Instead, after completing step 25, follow the instructions below and then click ahead to the next section "Step 3: Pivot into the new Subnet."**
    - You are encouraged to complete steps 26 - 34 during your study time to get more practice with these concepts.

  - In addition to the above steps, use information gathering modules to try to enumerate the information below. Note that not all modules will succeed. This is fine—just collect the information you can.

    - Currently logged-on users

    - Browsing history

    - Running services

    - SMB Shares

    - **Hint**: Search for `windows/gather`.

  - Search for `windows/gather/credentials` modules, and run at least 3 in addition to those used for the task above. Again, these may not succeed, but that's okay—the point is simply to see what you can get. You can use any modules you'd like, but consider looking for the following:

    - FTP credentials

    - Skype credentials

    - VNC credentials
    - **Hint**: You enumerated running services earlier. Instead of trying modules at random, see if there are any Metasploit modules for the services you discovered during your enumeration.

After you complete the instructions above, skip steps 26 - 34 and move onto complete steps 1 - 10 in **Part 3: Pivot into the new subnet**.
