## Student Activity: Who Is Tracy Texting?

### Instructions 

You've reviewed Tracy's email messages. Now, let's see who she's been texting:

Complete the following steps:

1. Use the file search to find the SMS database.

2. View the messages in the **Data Content** pane.

3. Analyze the text messages and phone numbers to establish any connections to the case, and answer the following:
- What is Terry's phone number?
- What is Pat's phone number?
- What was the fraudulent number that texted about a gift card? Is it relevant to the case? Why or why not?

4. Update your Evidence Worksheet with any additional evidence.
