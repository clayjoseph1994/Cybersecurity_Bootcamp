### Scanning with Metasploit

**Instructions**

  - Launch a Terminal and prepare the database.

    **Hint**: Initialize and start the msf database.

  - Launch `msfconsole`, then and perform a `db_nmap` scan to discover hosts and services for the `192.168.11.0/24` subnet. Verify that your scans identify the host you exploited in the previous session.

  - Use a scanner to determine which version of SSH is running on the target host.

    **Hint**: `scanner/ssh`.

  - Use the module to determine if the target is vulnerable to a brute-force attack.

    **Hint**: `check`

  - Create custom wordlists. Add `msfadmin` to the list of usernames and passwords.

**Hint** Use only the last three user names from the common.usr file and the last five passwords from the default.pwd file found in the `/usr/share/ncrack` directory. 
    
  - Exploit the host.
  - Use the credentials you discovered to log into the target.

**Questions:**

  - Which command would you use to determine the target's SSH version _without_ using Metasploit?

  - Which command would you run to perform a brute-force attack _without_ using Metasploit?

  - Name one advantage of using Metasploit's scanning modules over Nmap.

  - Name one disadvantage of using Metasploit's scanning modules over Nmap.
