## Instructions and Solutions:


- Use nmap to scan the `198.51.100.0/24` network.
 
   **Solution**: `nmap -sV 198.51.100.0/24`

- Use SSH to connect to the IP that has SSH Running on port 22 (Should be`198.51.100.1`).
 
  **Solution**: `ssh msfadmin@198.51.100.1`. Use the password `msfadmin`.

- Display the IP addresses of your attached interfaces.
  
  **Solution**: `ifconfig`. The `eth0` interface has IP address `10.10.10.200`.

- Inspect the results. You should have identified one new host.

  **Solution**: The new host should be `10.10.10.100`.

- Use Ncat to banner-grab the FTP and HTTP servers on the new host.
  
  **Solution**:
  
  To banner-grab the web server, run: `nc 10.10.10.100 80`, then send: `HEAD / HTTP/1.1`. Press `Enter` twice to get a response.
  
  To banner-grab the FTP server, run: `nc 10.10.10.100 21`, then wait until the connection times out (about 30 seconds).
