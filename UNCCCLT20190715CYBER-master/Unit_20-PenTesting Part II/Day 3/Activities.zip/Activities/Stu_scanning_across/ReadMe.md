## Scanning across Interfaces

**Instructions**

- Make sure you are using the machine **Kali WAN** Machine and not **Kali LAN**
   
    - To change machines, click on the 'Machines' tab on the right side of the lab window, in between the 'content' and 'support' tabs.

- Use nmap to scan the `198.51.100.0/24` network.

- Use SSH to connect to the machine that has port `22` open.

- Display the IP addresses of your attached interfaces on the victim machine.

- Use Nmap to perform a service scan of the new network (should be `10.10.10.0/24`). Save the results in a file called `/tmp/metainfo`.

- Inspect the results of your scan. You should have identified one new host.

- Use Ncat to banner-grab each service identified on this new host.

  - To banner-grab an HTTP server, connect with Ncat, then send: `GET / HTTP/1.1`.
    - this is an http request for `index.html`. if you get a response, you know the host is running an http server.
