### Scanning with Metasploit and Brute Force with Hydra


- Launch a Terminal, and run `msfconsole`. Return to your `dmz_scan` workspace, and issue `services`. Note that the IP address `198.51.100.1` is running an SSH server.

  ```bash
  $ msfconsole
  msf > workspace dmz_scan
  msf > services
  ```

- Notice that this verifies the target is running an SSH server, which means it may be susceptible to a brute force attack.

#### Wordlists

- Remember, brute force attacks take a long time to complete and send a lot of traffic. Besides just making you wait, the extra traffic can expose your machine to intrusion detection systems. To mitigate this, attackers often try to minimize the number of username/password combinations they use in a brute-force attempt.

- This typically entails the creation of a custom wordlist. Custom wordlists contain usernames and passwords that attackers think are especially likely to work. For example, someone brute-forcing an SSH server might use a list of [common service usernames](https://github.com/danielmiessler/SecLists/blob/master/Usernames/top-usernames-shortlist.txt) (such as `admin`, `mysql`, etc.) and [default passwords](https://github.com/danielmiessler/SecLists/tree/master/Passwords/Default-Credentials), instead of a list of "normal" usernames (`john`, `cathy`, etc.)

- Pentesters often use Kali's built-in wordlists as starting points for their own custom wordlists. Today, you'll have used them as a base to create short wordlists that won't generate a lot of traffic.

- Move to the `ncrack` directory, and extract the last 10 usernames and last 10 passwords with `tail`. Add `msfadmin` to both lists.

  **Note**: You use `tail` instead of `head` because the first lines in the `ncrack` wordlists contain metadata, which can't be used in a brute-force attack.

  ```bash
  msf > cd /usr/share/ncrack
  msf > tail -n 10 common.usr > short.username
  msf > echo "msfadmin" >> short.user
  msf > tail -n 10 default.pwd > short.password
  msf > echo "msfadmin" >> short.password
  ```

- Metasploit will try all 10 passwords with all 10 usernames, so this brute-force attack will try 100 (10 * 10) requests.

#### Exploitation

Continue the steps in CybrScore. 

- Notice that this discovers the credentials `msfadmin:msfadmin`.

- Before continuing you should always verify the results of a brute-force attack by hand, in case Metasploit reported a false positive.

- Run: `ssh msfadmin@198.51.100.1`. Press `Enter` when prompted and enter `msfadmin` as the password. This should drop you into a shell.

- Run: `whoami`. The shell will report that you're `msfadmin`, indicating that you've successfully connected to the target machine.

- Now that you have access to the machine you can now proceed to exploit the machine further. For example, you might:

  - Enumerate users and system information

  - Upload malicious files

  - Download sensitive data

- You will explore such tactics in the next session.

#### Mitigation

- There are two reasons this attack was possible:
  - The SSH server didn't throttle login attempts
  - Password login was enabled in the first place

Keep in mind the following

- A properly configured password login should lock users out after a certain number of failed login attempts. This is often called **throttling** authentication attempts.

- A properly configured SSH server shouldn't allow password login at all—users should be forced to use an SSH key instead.
  - **Note**: This SSH key should be password-protected, but the SSH server should not allow users to login with a password alone.

Normally a report about this engagement would include documentation (screenshots and description) of this exploitation process, as well as the above two mitigation recommendations.
