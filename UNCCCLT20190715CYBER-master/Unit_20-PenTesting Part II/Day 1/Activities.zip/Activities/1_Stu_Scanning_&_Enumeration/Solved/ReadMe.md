### Scanning and Enumeration

The following is the solution file for the activity that was handed to you in class. 

**Solution**


- Launch a Terminal in your Kali instance. Then, launch msfconsole and create a `dmz_scan` workspace.

  ```bash
  $ msfconsole

  msf > workspace -a dmz_scan
  ```

- Run `ifconfig` to display your network interfaces. Note the `eth0` and `eth1` interfaces, on subnets `192.168.1.50/24` and `192.168.11.0/24`. 

  ```bash
  msf > ifconfig

        eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.1.50  netmask 255.255.255.0  broadcast 192.168.99.255
        inet6 fe80::a00:27ff:feb6:b9e4  prefixlen 64  scopeid 0x20<link>
        ether 08:00:27:b6:b9:e4  txqueuelen 1000  (Ethernet)
        RX packets 20337  bytes 1609774 (1.5 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 14975  bytes 1270413 (1.2 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

        eth1: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.11.2  netmask 255.255.255.0  broadcast 192.168.99.255
        inet6 fe80::a00:27ff:feb6:b9e4  prefixlen 64  scopeid 0x20<link>
        ether 08:00:27:b6:b9:e4  txqueuelen 1000  (Ethernet)
        RX packets 20337  bytes 1609774 (1.5 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 14975  bytes 1270413 (1.2 MiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
  ```

- Scan these subnets with `db_nmap`. Also scan the `198.51.100.0/24` subnet. You'll discover eight hosts.

  ```bash
  msf > db_nmap -sS -T4 -O 192.168.1.0/24
  msf > db_nmap -sS -T4 -O 192.168.11.0/24
  msf > db_nmap -sS -T4 -O 198.51.100.0/24
  msf > hosts

  ```

- Finally, run a UDP scan against port 53 of the live hosts. The easiest way to do this is to simply pass the discovered IP addresses manually:

  ```bash
  msf > db_nmap -sU -p 53 192.168.1.25 192.168.1.100 192.168.11.3
  ```

- run UDP scans against at least the following ports:

  - `53`: DNS

  - `69`: TFTP

  - `137-139`: NetBIOS services

- Use the advanced flags from earlier, such as `-Pn` and `-n`, with UDP scans as well as with TCP scans.
