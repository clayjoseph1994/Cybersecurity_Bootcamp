### Scanning and Enumeration

**Introduction**

In this exercise, you will use Nmap to perform host and service discovery. You will also use Metasploit to store and explore scan results.


**Instructions**

For this exercise, log onto cyberscore and use lab instance **Pentesting & Network Exploitation: All Labs**. You will need to use the **Kali WAN** VM to complete the following:

- Run `ifconfig` to fetch the IP address of each of your network interfaces. Perform host discovery on each subnet you're connected to. Your scan should also perform passive OS detection.

- See what your scan discovered by running `hosts` and `services`.

- Repeat the above scans on the `198.51.100.0/24` subnet. Look at your `hosts` and `services` after running this scan.

- Next, perform a UDP scan of live targets. Scan the following ports: `53`, `69`, and `137`, `138`, and `139`.

  **Note**: The easiest way to do this is by manually passing IP addresses to the `db_nmap` command. Alternatively, you can use the `auxiliary/scanner/portscan/tcp` module, and use `hosts -R` to set `RHOSTS` equal to the list of `hosts` in your database. You'll see this in the review, but you can research it now if you'd like.

- Then, perform aggressive scans against the following hosts, using active OS detection.

  - `192.168.11.4`

  - `198.51.100.1`

  - `198.51.100.175`

- Use Ncat to banner-grab each service you discover on the above four hosts. Use this to verify your scan results—take note of any banners that don't match Nmap's original scan output.

- Finally, complete any other instructions detailed in **Part 13 - Scan Known Web-Facing Target IP** of the lab instructions.
