## Solution File: Warm-Up
In this exercise, you'll learn some advanced Nmap scanning techniques and review Shellshock.

Please launch the [Linux Exploitation](https://cybrscore.learnondemand.net/Lab/28535) lab and follow the instructions below.

### Solutions: 

#### Nmap
- Use Nmap to perform a ping sweep of your subnet. Save the results as XML.
  > **Solution**: `nmap -sP 10.0.0.0/24 -oX /tmp/host_discovery`
- Store the IP adderesses Nmap discovers in a file called `live_hosts`.
  - You'll have to copy them by hand. As a bonus, you can do this in bash with `awk` and `head`.
  > **Solution**: `awk -F '"' '/address/ {print $2}' /tmp/host_discovery | head -n 3 > /tmp/live_hosts`

- Run an "aggressive" scan of the top 100 ports against the hosts on the list.
  > **Solution**: `nmap --top-ports 100 -T4 -i /tmp/live_hosts`

- Repeat the scan above on just one of the hosts on the network. This time, turn off host discovery and name resolution to reduce the amount of traffic you send.
  > **Solution**: `nmap --top-ports 100 -T4 10.0.0.100 -Pn -n`

#### Shellshock
- What kind of vulnerability is Shellshock? What does it allow attackers to do?
  > **Solution**: Shellshock is a remote code execution vulnerability. It allows attackers to execute arbitrary bash code on remote systems.

- Which headers can be used to deliver a Shellshock payload? Give an example of how one of these headers might look in a malicious request.
  > **Solution**: Any header lodded by CGI can be attacked, including `HTTP_HOST`, `HTTP_USER_AGENT`, and `HTTP_REFERER`.
