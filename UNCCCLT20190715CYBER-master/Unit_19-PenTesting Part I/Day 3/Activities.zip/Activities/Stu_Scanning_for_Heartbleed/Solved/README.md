# Solution Guide: Scanning for Heartbleed

### Solutions:

- Use `searchsploit` to identify Heartbleed exploits.
  > **Solution**: `searchsploit heartbleed`

- Inspect the Python exploits you identify.
  > **Solution**: The two Python exploits are `32745.py` and `32764.py`. They both check a server for Heartbleed. `32764.py` is an updated version of `32745.py`, which adds SSL/TLS support.

- Move to the directory containing the original exploit, and attempt to run it.
  > **Solution**: `cd /usr/share/exploitdb/exploits/multiple/remote && python 32764.py

- Use Nmap to scan your local subnet.
  > **Solution**: `nmap -sP 10.0.0.0/24`

- Run the script you found with `searchsploit` against each host you discover. Record which ones are vulnerable.
  > **Solution**: `python 32764.py 10.0.0.101` reports a vulnerable server.
