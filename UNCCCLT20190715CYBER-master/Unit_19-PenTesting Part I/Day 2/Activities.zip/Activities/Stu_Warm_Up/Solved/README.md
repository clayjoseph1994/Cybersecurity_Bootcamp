## Solution File: Nmap Warm-Up
In this exercise, you will use the Nmap documentation to learn useful new flags. 

Refer to the following documentation as you work through the questions below: <https://nmap.org/book/man-port-scanning-techniques.html>

### Instructions 

- Write an Nmap command to perform a ping sweep of the range `10.0.0.0` to `10.0.0.254`.
    
   - **Solution**: `nmap -sP 10.0.0.0-254`. This reveals the hosts `10.0.0.10`, `10.0.0.100`, and `10.0.0.101`.
  
- Write an Nmap command to perform a service/version scan of the live hosts you discover. Save the results as XML to `/tmp/results.txt`. 
  
  - **Solution**: `nmap -sV 10.0.0.10 10.0.0.100-101 -oX /tmp/results.txt`
  
- Read about the `--top-ports` feature: <https://danielmiessler.com/blog/nmap-use-the-top-ports-option-for-both-tcp-and-udp-simultaneously/>. 
 
- Use `--top-ports` to scan the top 100 ports of the live hosts you discovered above. Save the results to an XML file.
  
  - **Solution**: `nmap --top-ports 100 10.0.0.10 10.0.0.100-101 -oX /tmp/top_ports`
  
- Use `--top-ports` to scan the top 20 ports of `scanme.nmap.org`. Save the results as a "normal" file.
  
  - **Solution**: `nmap --top-ports 20 scanme.nmap.org -oN results.txt`
