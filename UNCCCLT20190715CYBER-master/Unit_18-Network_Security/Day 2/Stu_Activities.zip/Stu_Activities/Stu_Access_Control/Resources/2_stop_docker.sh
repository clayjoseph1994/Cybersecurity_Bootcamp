#!/bin/bash

docker-compose down --remove-orphans
echo
echo "All Docker Containers Stopped."
echo
